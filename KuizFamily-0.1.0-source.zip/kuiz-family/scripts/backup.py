"""Signed database backup. PGPASSWORD is handled by PostgreSQL/libpq, never logged."""
import argparse,hashlib,hmac,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('action',choices=['backup','restore']);p.add_argument('file');p.add_argument('--key-file',required=True);p.add_argument('--confirm-restore',action='store_true');a=p.parse_args()
key=Path(a.key_file).read_bytes()
if len(key)<32: raise SystemExit('Backup signing key must contain at least 32 random bytes')
file=Path(a.file);sig=Path(str(file)+'.sha256-hmac')
if a.action=='backup':
    subprocess.run(['pg_dump','--format=custom','--file',str(file)],check=True)
    sig.write_text(hmac.new(key,file.read_bytes(),hashlib.sha256).hexdigest());os.chmod(file,0o600)
else:
    expected=hmac.new(key,file.read_bytes(),hashlib.sha256).hexdigest()
    if not hmac.compare_digest(sig.read_text().strip(),expected):raise SystemExit('Signature mismatch')
    if not a.confirm_restore:raise SystemExit('Signature OK. Restore into an EMPTY database using --confirm-restore')
    subprocess.run(['pg_restore','--exit-on-error','--no-owner','--dbname',os.environ['PGDATABASE'],str(file)],check=True)

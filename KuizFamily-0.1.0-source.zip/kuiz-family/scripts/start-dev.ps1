$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
if (!(Test-Path '.venv')) { py -3.13 -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if ($LASTEXITCODE -ne 0) { throw 'Не удалось установить зависимости' }
$env:COOKIE_SECURE='false'
$env:PUBLIC_ORIGIN='http://127.0.0.1:8078'
if (!$env:DATABASE_URL) { $env:DATABASE_URL='sqlite:///kuiz-dev.db' }
Set-Location backend
& ..\.venv\Scripts\python.exe -m flask --app kuiz db upgrade
if ($LASTEXITCODE -ne 0) { throw 'Не удалось применить миграции' }
Write-Host 'Kuiz Family: http://127.0.0.1:8078'
& ..\.venv\Scripts\python.exe -m flask --app kuiz run --host 127.0.0.1 --port 8078

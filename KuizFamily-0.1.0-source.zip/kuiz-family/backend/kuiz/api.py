import os, secrets, re, json, subprocess, tempfile, hashlib
from pathlib import Path
from functools import wraps
from flask import Blueprint, request, jsonify, g, abort, current_app, send_file
from argon2 import PasswordHasher
from argon2.exceptions import VerificationError, InvalidHashError
from sqlalchemy import select, update, or_
from .models import *
from . import digest, limit
api=Blueprint('api',__name__); ph=PasswordHasher()

def body():
    x=request.get_json(silent=True)
    if not isinstance(x,dict): abort(400,'Ожидается JSON-объект')
    return x

def string(x,k,maxlen=4000,required=True):
    v=x.get(k,'')
    if not isinstance(v,str) or len(v)>maxlen or (required and not v.strip()): abort(400,'Проверь поле '+k)
    return v.strip()

def number(x,k,default,lo,hi):
    v=x.get(k,default)
    if isinstance(v,bool) or not isinstance(v,int) or not lo<=v<=hi: abort(400,'Проверь поле '+k)
    return v

def auth(f):
    @wraps(f)
    def wrapped(*a,**kw):
        if not g.auth: abort(401,'Войди в аккаунт')
        return f(*a,**kw)
    return wrapped

def adult():
    if not g.auth or not g.auth.user_id: abort(403,'Нужен аккаунт взрослого')
    return db.session.get(User,g.auth.user_id)

def admin(trusted=False):
    u=adult()
    if not u.admin: abort(403,'Нет доступа')
    if trusted:
        grant=db.session.scalar(select(AdminGrant).where(AdminGrant.session_id==g.auth.id,AdminGrant.revoked==False,AdminGrant.expires>now()))
        if not grant: abort(403,'Сначала подтверди это устройство в разделе доверенных админ-устройств')
    return u

def actor(): return g.auth.user_id or g.auth.device_id

def member(fid,owner=False):
    if g.auth.device_id:
        d=db.session.get(Device,g.auth.device_id)
        if d.family_id!=fid or owner: abort(404)
        return None
    m=db.session.scalar(select(Membership).where(Membership.family_id==fid,Membership.user_id==g.auth.user_id))
    if not m or (owner and m.role!='family_owner'): abort(404)
    return m

def device(did):
    d=db.session.get(Device,did)
    if not d or d.revoked: abort(404)
    member(d.family_id)
    if g.auth.device_id and did!=g.auth.device_id: abort(404)
    return d

def message(mid,lock=False):
    q=select(Message).where(Message.id==mid)
    if lock: q=q.with_for_update()
    m=db.session.scalar(q)
    if not m: abort(404)
    device(m.device_id)
    return m

def check_password(hashed,p):
    try: return ph.verify(hashed,p)
    except (VerificationError,InvalidHashError): return False

def password(x):
    p=string(x,'password',256)
    if len(p)<12: abort(400,'Пароль должен содержать минимум 12 символов')
    return ph.hash(p)

def issue(user_id=None,device_id=None):
    token=secrets.token_urlsafe(48)
    s=Session(id=digest(token),user_id=user_id,device_id=device_id,expires=now()+(90 if device_id else 14)*86400,csrf=secrets.token_urlsafe(32))
    db.session.add(s); return token,s

def audit(action,target):
    e=Audit(id=uid(),actor=actor(),action=action,target=target);db.session.add(e);return e

def event(m,kind):
    seq=db.session.execute(update(Family).where(Family.id==m.family_id).values(sequence=Family.sequence+1).returning(Family.sequence)).scalar_one()
    e=Event(id=uid(),family_id=m.family_id,message_id=m.id,sequence=seq,kind=kind)
    db.session.add(e); db.session.flush()
    if kind=='scheduled': return e
    if kind in ('new','cancelled') and m.direction=='to_child':
        sessions=select(Session.id).where(Session.device_id==m.device_id,Session.expires>now())
    else:
        members=select(Membership.user_id).where(Membership.family_id==m.family_id)
        sessions=select(Session.id).where(Session.user_id.in_(members),Session.expires>now())
    for ins in db.session.scalars(select(Installation).where(Installation.session_id.in_(sessions))):
        if kind in ins.categories or (kind in ('new','cancelled') and m.direction=='to_child'):
            db.session.add(Job(installation_id=ins.id,message_id=m.id,event_id=e.id,kind=kind))
    return e

def wire(m):
    status='saved'
    for k in ('delivered','opened','confirmed','replied'):
        if getattr(m,k): status=k
    if m.send_at>now(): status='scheduled'
    if m.expires<=now() and not (m.confirmed or m.replied): status='expired'
    if m.cancelled: status='cancelled'
    sender=db.session.get(User,m.author) if m.direction=='to_child' else db.session.get(Device,m.device_id)
    return dict(id=m.id,device_id=m.device_id,sender_name=sender.name if sender else 'Семья',text=m.text,attachment_id=m.attachment_id,priority=m.priority,direction=m.direction,
        created=m.created,send_at=m.send_at,expires=m.expires,status=status,delivered=m.delivered,opened=m.opened,confirmed=m.confirmed,replied=m.replied,
        replies=[dict(id=r.id,text=r.text,attachment_id=r.attachment_id,created=r.created,author=r.author) for r in db.session.scalars(select(Reply).where(Reply.message_id==m.id).order_by(Reply.created))])

@api.get('/me')
@auth
def me():
    if g.auth.device_id:
        d=device(g.auth.device_id); f=db.session.get(Family,d.family_id)
        people=[db.session.get(User,m.user_id).name for m in db.session.scalars(select(Membership).where(Membership.family_id==f.id))]
        return jsonify(role='child_device',device_id=d.id,name=d.name,family_id=f.id,family_name=f.name,adults=people,session_expires=g.auth.expires)
    u=adult()
    return jsonify(id=u.id,name=u.name,email=u.email,admin=u.admin,csrf=g.auth.csrf,
        families=[dict(id=m.family_id,name=db.session.get(Family,m.family_id).name,role=m.role) for m in db.session.scalars(select(Membership).where(Membership.user_id==u.id))])

@api.post('/auth/login')
def login():
    limit('login-ip:'+request.remote_addr,20)
    x=body(); email=string(x,'email',254).lower(); limit('login:'+email,10)
    u=db.session.scalar(select(User).where(User.email==email))
    if not u or not check_password(u.password,string(x,'password',256)): abort(401,'Неверный email или пароль')
    token,s=issue(user_id=u.id); db.session.commit()
    r=jsonify(csrf=s.csrf); r.set_cookie('kf_session',token,httponly=True,secure=current_app.config['COOKIE_SECURE'],samesite='Strict',max_age=14*86400)
    return r

@api.post('/auth/logout')
@auth
def logout():
    for i in db.session.scalars(select(Installation).where(Installation.session_id==g.auth.id)):
        db.session.query(Job).filter_by(installation_id=i.id).delete(); db.session.delete(i)
    db.session.query(AdminGrant).filter_by(session_id=g.auth.id).delete()
    db.session.delete(g.auth); db.session.commit()
    r=jsonify(ok=True); r.delete_cookie('kf_session'); return r

@api.post('/auth/invites/redeem')
def redeem():
    limit('redeem:'+request.remote_addr)
    x=body(); inv=db.session.scalar(select(Invite).where(Invite.id==digest(string(x,'token',200))).with_for_update())
    if not inv or inv.used or inv.expires<=now() or inv.purpose!='invite': abort(400,'Приглашение недействительно')
    if string(x,'email',254).lower()!=inv.email: abort(400,'Приглашение выписано на другой email')
    u=User(id=uid(),email=inv.email,name=string(x,'name',80),password=password(x)); db.session.add(u)
    if inv.family_id: db.session.add(Membership(family_id=inv.family_id,user_id=u.id,role=inv.role))
    inv.used=True; db.session.commit(); return jsonify(ok=True),201

@api.post('/auth/reset/request')
def reset_request():
    limit('reset:'+request.remote_addr,4,3600)
    x=body(); u=db.session.scalar(select(User).where(User.email==string(x,'email',254).lower()))
    if u:
        from .mail import send_link
        token=secrets.token_urlsafe(32)
        db.session.add(Invite(id=digest(token),email=u.email,expires=now()+1800,purpose='reset'))
        send_link(u.email,token,'reset'); db.session.commit()
    return jsonify(ok=True)

@api.post('/auth/reset/confirm')
def reset_confirm():
    limit('reset-confirm:'+request.remote_addr)
    x=body(); inv=db.session.scalar(select(Invite).where(Invite.id==digest(string(x,'token',200))).with_for_update())
    if not inv or inv.used or inv.expires<=now() or inv.purpose!='reset': abort(400,'Ссылка недействительна')
    u=db.session.scalar(select(User).where(User.email==inv.email)); u.password=password(x); inv.used=True
    # Revoke every session and its push destinations.
    for s in db.session.scalars(select(Session).where(Session.user_id==u.id)):
        s.expires=0
    db.session.commit(); return jsonify(ok=True)

@api.post('/families')
@auth
def families():
    u=adult(); x=body(); f=Family(id=uid(),name=string(x,'name',80)); db.session.add(f)
    db.session.add(Membership(family_id=f.id,user_id=u.id,role='family_owner')); audit('family.create',f.id)
    db.session.commit(); return jsonify(id=f.id),201

@api.post('/families/<fid>/invite-adult')
@api.post('/admin/invites')
@auth
def invite(fid=None):
    if fid: member(fid,True)
    else: admin(trusted=True)
    limit('invite:'+actor(),10,3600); x=body(); email=string(x,'email',254).lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): abort(400,'Проверь email')
    token=secrets.token_urlsafe(32)
    db.session.add(Invite(id=digest(token),email=email,family_id=fid,expires=now()+48*3600))
    from .mail import send_link
    send_link(email,token,'invite'); audit('invite.create',fid or 'platform'); db.session.commit()
    return jsonify(ok=True),201

@api.post('/pairings')
def pair():
    limit('pair:'+request.remote_addr,15)
    x=body(); code=''.join(secrets.choice('ABCDEFGHJKLMNPQRSTUVWXYZ23456789') for _ in range(8)); secret=secrets.token_urlsafe(32)
    p=Pairing(id=uid(),code_hash=digest(code),secret_hash=digest(secret),name=string(x,'name',80),expires=now()+300)
    db.session.add(p); db.session.commit(); return jsonify(id=p.id,code=code,secret=secret,expires=p.expires),201

@api.post('/pairings/confirm')
@auth
def pair_confirm():
    adult(); limit('pair-confirm:'+actor(),10); x=body(); fid=string(x,'family_id',36); member(fid)
    p=db.session.scalar(select(Pairing).where(Pairing.code_hash==digest(string(x,'code',8).upper())).with_for_update())
    if not p or p.expires<=now() or p.device_id or p.consumed: abort(400,'Код истёк или уже использован')
    if 'confirm' in x and not isinstance(x['confirm'],bool):abort(400,'confirm должен быть boolean')
    if not x.get('confirm'): return jsonify(name=p.name,expires=p.expires)
    d=Device(id=uid(),family_id=fid,name=p.name); db.session.add(d); p.device_id=d.id
    audit('device.pair',d.id); db.session.commit(); return jsonify(id=d.id,name=d.name),201

@api.post('/pairings/<pid>/claim')
def pair_claim(pid):
    limit('pair-claim:'+request.remote_addr,120)
    x=body(); p=db.session.scalar(select(Pairing).where(Pairing.id==pid).with_for_update())
    if not p or p.expires<=now() or p.consumed or not secrets.compare_digest(p.secret_hash,digest(string(x,'secret',200))): abort(400,'Привязка недействительна')
    if not p.device_id: return jsonify(waiting=True),202
    token,s=issue(device_id=p.device_id); p.consumed=True; db.session.commit()
    return jsonify(token=token,device_id=p.device_id,expires=s.expires)

@api.post('/pairings/<pid>/cancel')
def pair_cancel(pid):
    limit('pair-cancel:'+request.remote_addr)
    x=body(); p=db.session.get(Pairing,pid)
    if not p or not secrets.compare_digest(p.secret_hash,digest(string(x,'secret',200))): abort(404)
    if p.device_id: abort(409,'Устройство уже подтверждено взрослым')
    p.consumed=True; db.session.commit(); return jsonify(ok=True)

@api.get('/devices')
@auth
def devices():
    if g.auth.device_id: rows=[device(g.auth.device_id)]
    else:
        ids=select(Membership.family_id).where(Membership.user_id==actor())
        rows=db.session.scalars(select(Device).where(Device.family_id.in_(ids),Device.revoked==False))
    return jsonify(items=[dict(id=d.id,name=d.name,family_id=d.family_id,last_seen=d.seen,online=bool(d.seen and now()-d.seen<120),info=d.info) for d in rows])

@api.post('/devices/<did>/heartbeat')
@auth
def heartbeat(did):
    if g.auth.device_id!=did: abort(403)
    d=device(did); x=body(); d.seen=now()
    d.info=dict(version=string(x,'version',40,False),notifications=bool(x.get('notifications',False)))
    if 'battery' in x: d.info['battery']=number(x,'battery',0,0,100)
    db.session.commit(); return jsonify(ok=True,server_time=now())

@api.post('/devices/<did>/revoke')
@auth
def revoke(did):
    u=adult(); limit('revoke:'+u.id); x=body()
    if not check_password(u.password,string(x,'password',256)): abort(403,'Неверный пароль')
    d=device(did); d.revoked=True; audit('device.revoke',did); db.session.commit(); return jsonify(ok=True)

@api.post('/families/<fid>/pin')
@auth
def set_pin(fid):
    u=adult(); member(fid,True); limit('pin-set:'+u.id); x=body()
    if not check_password(u.password,string(x,'password',256)): abort(403)
    pin=string(x,'pin',12)
    if not re.fullmatch(r'\d{6,12}',pin): abort(400,'PIN: от 6 до 12 цифр')
    db.session.get(Family,fid).pin_hash=ph.hash(pin); audit('pin.set',fid); db.session.commit(); return jsonify(ok=True)

@api.post('/parent-access')
@auth
def parent_access():
    if not g.auth.device_id: abort(403)
    limit('pin:'+actor(),5,900); x=body(); d=device(actor()); f=db.session.get(Family,d.family_id)
    if not f.pin_hash or not check_password(f.pin_hash,string(x,'pin',12)): abort(403,'Неверный PIN или PIN не настроен')
    e=audit('pin.accepted',d.id)
    members=select(Membership.user_id).where(Membership.family_id==d.family_id)
    sessions=select(Session.id).where(Session.user_id.in_(members),Session.expires>now())
    for ins in db.session.scalars(select(Installation).where(Installation.session_id.in_(sessions))):
        db.session.add(Job(installation_id=ins.id,message_id='',event_id=e.id,kind='parent_access'))
    db.session.commit(); return jsonify(until=now()+300)

def attachment_check(aid,fid):
    if not aid: return None
    if not isinstance(aid,str): abort(400)
    a=db.session.get(Attachment,aid)
    if not a or a.family_id!=fid or a.owner!=actor() or a.expires<=now(): abort(404)
    return aid

@api.post('/messages')
@auth
def send():
    limit('send:'+actor(),60,60); x=body(); d=device(string(x,'device_id',36)); key=string(x,'key',100)
    old=db.session.scalar(select(Message).where(Message.author==actor(),Message.key==key,Message.device_id==d.id))
    if old: return jsonify(wire(old))
    text=string(x,'text',4000,False); aid=attachment_check(x.get('attachment_id'),d.family_id)
    if not text and not aid: abort(400,'Добавь текст или запись')
    sent=number(x,'send_at',now(),now()-60,now()+90*86400)
    expiry=number(x,'expires',sent+86400,sent+60,sent+30*86400)
    m=Message(id=uid(),family_id=d.family_id,device_id=d.id,author=actor(),key=key,text=text,attachment_id=aid,
        priority=number(x,'priority',0,0,2),send_at=sent,expires=expiry,direction='to_parent' if g.auth.device_id else 'to_child',dispatched=sent<=now())
    db.session.add(m); db.session.flush(); event(m,'new' if m.dispatched else 'scheduled'); db.session.commit()
    return jsonify(wire(m)),201

@api.get('/messages')
@auth
def messages():
    q=select(Message)
    if g.auth.device_id: q=q.where(Message.device_id==actor(),Message.send_at<=now())
    else: q=q.where(Message.family_id.in_(select(Membership.family_id).where(Membership.user_id==actor())))
    cursor=request.args.get('cursor')
    if cursor:
        try: stamp,mid=cursor.split(':',1);stamp=int(stamp)
        except (ValueError,TypeError): abort(400,'Неверный cursor')
        q=q.where(or_(Message.created<stamp,(Message.created==stamp)&(Message.id>mid)))
    rows=list(db.session.scalars(q.order_by(Message.created.desc(),Message.id).limit(200)))
    return jsonify(items=[wire(m) for m in rows],next_cursor=str(rows[-1].created)+':'+rows[-1].id if len(rows)==200 else None)

@api.get('/messages/<mid>')
@auth
def get_message(mid): return jsonify(wire(message(mid)))

@api.post('/messages/<mid>/events')
@auth
def ack(mid):
    x=body(); kind=string(x,'kind',24); m=message(mid,True)
    if (m.direction=='to_child' and g.auth.device_id!=m.device_id) or (m.direction=='to_parent' and not g.auth.user_id): abort(403)
    if kind not in ('delivered','opened','confirmed'): abort(400)
    if m.cancelled or m.expires<=now(): abort(409,'Сообщение отменено или просрочено')
    if not getattr(m,kind):
        setattr(m,kind,now()); event(m,kind)
    db.session.commit(); return jsonify(wire(m))

@api.post('/messages/<mid>/reply')
@auth
def reply(mid):
    x=body(); m=message(mid,True); key=string(x,'key',100)
    old=db.session.scalar(select(Reply).where(Reply.author==actor(),Reply.key==key))
    if old:
        if old.message_id!=mid: abort(409)
        return jsonify(id=old.id)
    if m.cancelled: abort(409,'Сообщение отменено')
    txt=string(x,'text',4000,False); aid=attachment_check(x.get('attachment_id'),m.family_id)
    if not txt and not aid: abort(400)
    r=Reply(id=uid(),message_id=mid,author=actor(),key=key,text=txt,attachment_id=aid)
    db.session.add(r); m.replied=now(); event(m,'replied'); db.session.commit(); return jsonify(id=r.id),201

@api.post('/messages/<mid>/cancel')
@auth
def cancel(mid):
    adult(); m=message(mid,True)
    if not m.cancelled: m.cancelled=now(); event(m,'cancelled')
    db.session.commit(); return jsonify(wire(m))

@api.get('/notifications')
@auth
def notifications():
    q=select(Event).where(Event.family_id.in_(select(Membership.family_id).where(Membership.user_id==actor()))) if g.auth.user_id else select(Event).join(Message).where(Message.device_id==actor())
    return jsonify(items=[dict(id=e.id,message_id=e.message_id,kind=e.kind,sequence=e.sequence,created=e.created) for e in db.session.scalars(q.order_by(Event.created.desc()).limit(100))])

@api.post('/push/register')
@auth
def push_register():
    x=body(); fid=string(x,'fid',256); platform=string(x,'platform',16)
    if platform not in ('web','android'): abort(400)
    ins=db.session.scalar(select(Installation).where(Installation.fid==fid))
    if ins and ins.session_id!=g.auth.id:
        previous=db.session.get(Session,ins.session_id)
        if not previous or (previous.user_id,previous.device_id)!=(g.auth.user_id,g.auth.device_id): abort(409,'Эта push-регистрация принадлежит другому аккаунту')
        ins.session_id=g.auth.id
    if not ins: ins=Installation(session_id=g.auth.id,fid=fid,platform=platform); db.session.add(ins)
    cats=x.get('categories',ins.categories or ['new','confirmed','replied'])
    if not isinstance(cats,list) or any(k not in ['new','delivered','opened','confirmed','replied','cancelled'] for k in cats): abort(400)
    ins.categories=cats; db.session.commit(); return jsonify(id=ins.id)

@api.post('/attachments')
@auth
def upload():
    limit('upload:'+actor(),20,3600)
    fid=request.form.get('family_id',''); member(fid); f=request.files.get('file')
    if not f: abort(400)
    key=request.form.get('key')
    if not key or len(key)>100:abort(400,'Нужен ключ идемпотентной загрузки')
    old=db.session.scalar(select(Attachment).where(Attachment.owner==actor(),Attachment.key==key))
    if old:
        if old.family_id!=fid:abort(409)
        return jsonify(id=old.id,mime=old.mime)
    db.session.scalar(select(Family).where(Family.id==fid).with_for_update())
    from sqlalchemy import func
    used=db.session.scalar(select(func.coalesce(func.sum(Attachment.size),0)).where(Attachment.family_id==fid,Attachment.expires>now()))
    if used>200*1024*1024: abort(413,'Семейная квота медиа 200 МБ исчерпана')
    raw=f.read(21*1024*1024)
    if len(raw)>20*1024*1024: abort(413,'Запись больше 20 МБ')
    # Verify container AND streams using ffprobe; never trust a supplied MIME or extension.
    root=Path(current_app.config['MEDIA_ROOT']); aid=uid(); p=root/aid; p.write_bytes(raw)
    try:
        res=subprocess.run(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(p)],capture_output=True,timeout=15,check=True)
        meta=json.loads(res.stdout); duration=float(meta['format']['duration'])
        kinds={s['codec_type'] for s in meta['streams']}
        if not 0<duration<=90 or not kinds.issubset({'audio','video'}) or not kinds: raise ValueError()
        fmt=meta['format']['format_name']
        mime=('video/' if 'video' in kinds else 'audio/')+('webm' if 'webm' in fmt else 'mp4' if 'mp4' in fmt else 'ogg' if 'ogg' in fmt else '')
        if mime.endswith('/'): raise ValueError()
    except (ValueError,KeyError,subprocess.SubprocessError,FileNotFoundError):
        p.unlink(missing_ok=True); abort(400,'Нужна аудио/видеозапись до 90 секунд; серверу требуется ffprobe')
    a=Attachment(id=aid,key=key,family_id=fid,owner=actor(),mime=mime,size=len(raw),expires=now()+current_app.config['RETENTION_DAYS']*86400)
    db.session.add(a); db.session.commit(); return jsonify(id=aid,mime=mime),201

@api.get('/attachments/<aid>')
@auth
def download(aid):
    a=db.session.get(Attachment,aid)
    if not a or a.expires<=now(): abort(404)
    member(a.family_id)
    if g.auth.device_id and a.owner!=actor():
        mids=select(Message.id).where(Message.device_id==actor())
        linked=db.session.scalar(select(Message.id).where(Message.device_id==actor(),Message.attachment_id==aid)) or db.session.scalar(select(Reply.id).where(Reply.message_id.in_(mids),Reply.attachment_id==aid))
        if not linked: abort(404)
    return send_file(Path(current_app.config['MEDIA_ROOT'])/a.id,mimetype=a.mime,conditional=True)

@api.delete('/attachments/<aid>')
@auth
def delete_attachment(aid):
    a=db.session.get(Attachment,aid)
    if not a: abort(404)
    member(a.family_id)
    if g.auth.device_id and a.owner!=actor(): abort(403)
    a.expires=0; db.session.commit(); return jsonify(ok=True)

@api.get('/admin/health')
@auth
def health():
    admin(); db.session.execute(select(1))
    return jsonify(database='ok',fcm_configured=bool(os.getenv('GOOGLE_APPLICATION_CREDENTIALS')),users=db.session.query(User).count(),families=db.session.query(Family).count(),devices=db.session.query(Device).count(),pending=db.session.query(Job).filter_by(state='pending').count(),failed=db.session.query(Job).filter_by(state='failed').count(),
        audit=[dict(action=a.action,target=a.target,created=a.created) for a in db.session.scalars(select(Audit).order_by(Audit.created.desc()).limit(30))])

@api.post('/admin/test-push')
@auth
def test_push():
    admin(trusted=True); limit('testpush:'+actor(),3,60); x=body()
    ins=db.session.get(Installation,string(x,'installation_id',36))
    if not ins or ins.session_id!=g.auth.id: abort(404)
    from .worker import send_push
    try: send_push(ins,dict(type='test',message_id='',event_id=uid()),dry_run=not bool(x.get('real')))
    except Exception: abort(503,'Firebase не настроен или отклонил тест. Проверь конфигурацию и регистрацию устройства.')
    audit('push.test',ins.id); db.session.commit(); return jsonify(accepted_by_fcm=True,device_ack=False)

@api.get('/admin/devices')
@auth
def admin_devices():
    admin()
    return jsonify(items=[dict(id=r.id,name=r.name,expires=r.expires,revoked=r.revoked,current=r.session_id==g.auth.id) for r in db.session.scalars(select(AdminGrant).join(Session,AdminGrant.session_id==Session.id).where(Session.user_id==actor()))])

@api.post('/admin/devices/trust')
@auth
def admin_trust():
    u=admin(); limit('trust:'+u.id,5,900); x=body()
    if not check_password(u.password,string(x,'password',256)): abort(403,'Неверный пароль')
    r=db.session.scalar(select(AdminGrant).where(AdminGrant.session_id==g.auth.id))
    if not r: r=AdminGrant(session_id=g.auth.id,name=string(x,'name',80),expires=now()+86400);db.session.add(r)
    r.expires=now()+86400;r.revoked=False;audit('admin.trust',g.auth.id[:12]);db.session.commit();return jsonify(id=r.id,expires=r.expires)

@api.post('/admin/devices/<gid>/revoke')
@auth
def admin_revoke(gid):
    u=admin();r=db.session.get(AdminGrant,gid)
    if not r or db.session.get(Session,r.session_id).user_id!=u.id: abort(404)
    r.revoked=True;audit('admin.revoke',r.id);db.session.commit();return jsonify(ok=True)

@api.post('/auth/refresh')
@auth
def refresh():
    limit('refresh:'+actor(),10,3600)
    old=g.auth;token,new=issue(user_id=old.user_id,device_id=old.device_id);db.session.flush()
    for ins in db.session.scalars(select(Installation).where(Installation.session_id==old.id)):ins.session_id=new.id
    db.session.query(AdminGrant).filter_by(session_id=old.id).delete()
    db.session.delete(old);db.session.commit()
    if new.device_id:return jsonify(token=token,expires=new.expires)
    r=jsonify(csrf=new.csrf);r.set_cookie('kf_session',token,httponly=True,secure=current_app.config['COOKIE_SECURE'],samesite='Strict',max_age=14*86400);return r

@api.get('/families/<fid>/members')
@auth
def family_members(fid):
    member(fid)
    return jsonify(items=[dict(id=m.id,name=db.session.get(User,m.user_id).name,role=m.role) for m in db.session.scalars(select(Membership).where(Membership.family_id==fid))])

@api.delete('/families/<fid>/members/<mid>')
@auth
def remove_member(fid,mid):
    u=adult();member(fid,True);limit('remove-member:'+u.id);x=body()
    if not check_password(u.password,string(x,'password',256)):abort(403)
    m=db.session.get(Membership,mid)
    if not m or m.family_id!=fid:abort(404)
    if m.role=='family_owner':abort(409,'Нельзя удалить владельца семьи')
    db.session.delete(m);audit('member.remove',mid);db.session.commit();return jsonify(ok=True)

@api.get('/push/installations')
@auth
def own_installations():
    return jsonify(items=[dict(id=i.id,platform=i.platform,categories=i.categories) for i in db.session.scalars(select(Installation).where(Installation.session_id==g.auth.id))])

@api.post('/push/installations/<iid>/preferences')
@auth
def push_preferences(iid):
    i=db.session.get(Installation,iid)
    if not i or i.session_id!=g.auth.id:abort(404)
    cats=body().get('categories')
    if not isinstance(cats,list) or any(c not in ['new','delivered','opened','confirmed','replied','cancelled'] for c in cats):abort(400)
    i.categories=cats;db.session.commit();return jsonify(ok=True)

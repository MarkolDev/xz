import click, secrets
from sqlalchemy import select
from .models import *
from .api import ph
from . import digest

def register_cli(app):
    @app.cli.command('create-admin')
    @click.option('--email',prompt=True)
    @click.option('--name',prompt=True)
    @click.password_option(confirmation_prompt=True)
    def create_admin(email,name,password):
        if len(password)<12: raise click.ClickException('Минимум 12 символов')
        db.session.add(User(email=email.strip().lower(),name=name,password=ph.hash(password),admin=True))
        db.session.commit(); click.echo('Администратор создан. Создай семью после входа.')
    @app.cli.command('invite')
    @click.option('--email',required=True)
    def invite(email):
        """Offline admin recovery/bootstrap; deliver this secret to the named email only."""
        token=secrets.token_urlsafe(32)
        db.session.add(Invite(id=digest(token),email=email.lower(),expires=now()+48*3600)); db.session.commit()
        click.echo('Передай ссылку ТОЛЬКО владельцу указанного email:')
        click.echo(app.config['PUBLIC_ORIGIN']+'/#invite='+token)
    @app.cli.command('retry-push')
    def retry_push():
        db.session.query(Job).filter_by(state='failed').update({'state':'pending','attempts':0,'due':now()}); db.session.commit()

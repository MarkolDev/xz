import time, uuid
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import UniqueConstraint

db = SQLAlchemy()
# Match production FK behaviour in SQLite development/tests.
from sqlalchemy import event as sa_event
from sqlalchemy.engine import Engine
import sqlite3
@sa_event.listens_for(Engine, 'connect')
def sqlite_foreign_keys(connection, _):
    if isinstance(connection, sqlite3.Connection):
        cursor=connection.cursor();cursor.execute('PRAGMA foreign_keys=ON');cursor.close()

def uid(): return str(uuid.uuid4())
def now(): return int(time.time())

class User(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    email = db.Column(db.String(254), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)
    password = db.Column(db.Text, nullable=False)
    admin = db.Column(db.Boolean, default=False, nullable=False)

class Family(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    name = db.Column(db.String(80), nullable=False)
    sequence = db.Column(db.Integer, default=0, nullable=False)
    pin_hash = db.Column(db.Text)

class Membership(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    family_id = db.Column(db.ForeignKey('family.id'), nullable=False, index=True)
    user_id = db.Column(db.ForeignKey('user.id'), nullable=False, index=True)
    role = db.Column(db.String(20), nullable=False)
    __table_args__ = (UniqueConstraint('family_id','user_id'),)

class Session(db.Model):
    id = db.Column(db.String(64), primary_key=True)
    user_id = db.Column(db.ForeignKey('user.id'))
    device_id = db.Column(db.String(36))
    expires = db.Column(db.BigInteger, nullable=False)
    csrf = db.Column(db.String(64), nullable=False)

class Invite(db.Model):
    id = db.Column(db.String(64), primary_key=True)
    email = db.Column(db.String(254), nullable=False)
    family_id = db.Column(db.ForeignKey('family.id'))
    role = db.Column(db.String(20), nullable=False, default='parent')
    expires = db.Column(db.BigInteger, nullable=False)
    used = db.Column(db.Boolean, default=False, nullable=False)
    purpose = db.Column(db.String(16), default='invite', nullable=False)

class Device(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    family_id = db.Column(db.ForeignKey('family.id'), nullable=False, index=True)
    name = db.Column(db.String(80), nullable=False)
    revoked = db.Column(db.Boolean, default=False, nullable=False)
    seen = db.Column(db.BigInteger)
    info = db.Column(db.JSON, default=dict, nullable=False)

class Pairing(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    code_hash = db.Column(db.String(64), unique=True, nullable=False)
    secret_hash = db.Column(db.String(64), nullable=False)
    name = db.Column(db.String(80), nullable=False)
    expires = db.Column(db.BigInteger, nullable=False)
    device_id = db.Column(db.ForeignKey('device.id'))
    consumed = db.Column(db.Boolean, default=False, nullable=False)

class Message(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    family_id = db.Column(db.ForeignKey('family.id'), nullable=False, index=True)
    device_id = db.Column(db.ForeignKey('device.id'), nullable=False, index=True)
    author = db.Column(db.String(36), nullable=False)
    direction = db.Column(db.String(16), nullable=False, default='to_child')
    key = db.Column(db.String(100), nullable=False)
    text = db.Column(db.Text, nullable=False, default='')
    attachment_id = db.Column(db.String(36))
    priority = db.Column(db.Integer, default=0, nullable=False)
    created = db.Column(db.BigInteger, default=now, nullable=False)
    send_at = db.Column(db.BigInteger, default=now, nullable=False, index=True)
    expires = db.Column(db.BigInteger, nullable=False)
    cancelled = db.Column(db.BigInteger)
    dispatched = db.Column(db.Boolean, default=False, nullable=False)
    delivered = db.Column(db.BigInteger)
    opened = db.Column(db.BigInteger)
    confirmed = db.Column(db.BigInteger)
    replied = db.Column(db.BigInteger)
    __table_args__ = (UniqueConstraint('author','key','device_id'),)

class Event(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    family_id = db.Column(db.ForeignKey('family.id'), nullable=False, index=True)
    message_id = db.Column(db.ForeignKey('message.id'), nullable=False, index=True)
    sequence = db.Column(db.Integer, nullable=False)
    kind = db.Column(db.String(24), nullable=False)
    created = db.Column(db.BigInteger, default=now, nullable=False)
    __table_args__ = (UniqueConstraint('family_id','sequence'),)

class Reply(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    message_id = db.Column(db.ForeignKey('message.id'), nullable=False, index=True)
    author = db.Column(db.String(36), nullable=False)
    key = db.Column(db.String(100), nullable=False)
    text = db.Column(db.Text, nullable=False)
    attachment_id = db.Column(db.String(36))
    created = db.Column(db.BigInteger, default=now, nullable=False)
    __table_args__ = (UniqueConstraint('author','key'),)

class Attachment(db.Model):
    key = db.Column(db.String(100), nullable=True)
    __table_args__ = (UniqueConstraint('owner','key',name='uq_attachment_owner_key'),)
    id = db.Column(db.String(36), primary_key=True, default=uid)
    family_id = db.Column(db.ForeignKey('family.id'), nullable=False)
    owner = db.Column(db.String(36), nullable=False)
    mime = db.Column(db.String(64), nullable=False)
    size = db.Column(db.Integer, nullable=False)
    expires = db.Column(db.BigInteger, nullable=False)

class Installation(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    session_id = db.Column(db.ForeignKey('session.id'), nullable=False, index=True)
    fid = db.Column(db.String(256), nullable=False, unique=True)
    platform = db.Column(db.String(16), nullable=False)
    categories = db.Column(db.JSON, default=lambda:['new','confirmed','replied'], nullable=False)

class Job(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    installation_id = db.Column(db.ForeignKey('installation.id'), nullable=False)
    message_id = db.Column(db.String(36), nullable=False)
    event_id = db.Column(db.String(36), nullable=False)
    kind = db.Column(db.String(24), nullable=False)
    due = db.Column(db.BigInteger, default=now, nullable=False, index=True)
    attempts = db.Column(db.Integer, default=0, nullable=False)
    state = db.Column(db.String(16), default='pending', nullable=False)
    error = db.Column(db.String(100))

class Audit(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    actor = db.Column(db.String(36), nullable=False)
    action = db.Column(db.String(80), nullable=False)
    target = db.Column(db.String(100), nullable=False)
    created = db.Column(db.BigInteger, default=now, nullable=False)

class Rate(db.Model):
    id = db.Column(db.String(64), primary_key=True)
    count = db.Column(db.Integer, nullable=False)
    until = db.Column(db.BigInteger, nullable=False)

class Release(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    channel = db.Column(db.String(16), nullable=False)
    version_code = db.Column(db.Integer, nullable=False)
    version_name = db.Column(db.String(100), nullable=False)
    sha256 = db.Column(db.String(64), nullable=False)
    cert = db.Column(db.String(64), nullable=False)
    size = db.Column(db.Integer, nullable=False)
    notes = db.Column(db.Text, default='', nullable=False)
    rollout = db.Column(db.Integer, default=100, nullable=False)
    advisory = db.Column(db.Boolean, default=False, nullable=False)
    published = db.Column(db.Boolean, default=False, nullable=False)
    __table_args__ = (UniqueConstraint('channel','version_code'),)

class AdminGrant(db.Model):
    id = db.Column(db.String(36), primary_key=True, default=uid)
    session_id = db.Column(db.ForeignKey('session.id'), unique=True, nullable=False)
    name = db.Column(db.String(80), nullable=False)
    expires = db.Column(db.BigInteger, nullable=False)
    revoked = db.Column(db.Boolean, default=False, nullable=False)

import os, secrets, hashlib, json
from pathlib import Path
from flask import Flask, request, g, jsonify, send_from_directory
from flask_migrate import Migrate
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from werkzeug.exceptions import HTTPException
from .models import db, Session, Device, now, Rate

def digest(s): return hashlib.sha256(s.encode()).hexdigest()
def create_app(config=None):
    app = Flask(__name__, static_folder=None)
    root = Path(__file__).resolve().parents[2]
    app.config.update(SQLALCHEMY_DATABASE_URI=os.getenv('DATABASE_URL','sqlite:///kuiz-dev.db'),
        SQLALCHEMY_TRACK_MODIFICATIONS=False, COOKIE_SECURE=os.getenv('COOKIE_SECURE','true')=='true',
        PUBLIC_ORIGIN=os.getenv('PUBLIC_ORIGIN','https://kfml.markol.fun'),
        MAX_CONTENT_LENGTH=100*1024*1024, MEDIA_ROOT=os.getenv('MEDIA_ROOT',str(root/'data')),
        WEB_ROOT=str(root/'web'/'dist'), RETENTION_DAYS=int(os.getenv('RETENTION_DAYS','30')))
    if config: app.config.update(config)
    Path(app.config['MEDIA_ROOT']).mkdir(parents=True,exist_ok=True)
    db.init_app(app); Migrate(app, db)
    @app.before_request
    def security():
        g.auth = None
        token = request.headers.get('Authorization','')
        bearer = token.startswith('Bearer ')
        raw = token[7:] if bearer else request.cookies.get('kf_session','')
        if raw:
            s = db.session.get(Session,digest(raw))
            if s and s.expires > now():
                d = db.session.get(Device,s.device_id) if s.device_id else None
                if not s.device_id or (d and not d.revoked): g.auth=s
        if request.path.startswith('/api/') and request.method not in ('GET','HEAD','OPTIONS'):
            origin = request.headers.get('Origin')
            if origin and origin != app.config['PUBLIC_ORIGIN']: return jsonify(error='Недопустимый источник'),403
            if g.auth and not bearer and not secrets.compare_digest(request.headers.get('X-CSRF-Token',''),g.auth.csrf):
                return jsonify(error='Обнови страницу: CSRF'),403
    @app.after_request
    def headers(r):
        r.headers['X-Content-Type-Options']='nosniff'
        r.headers['Referrer-Policy']='no-referrer'
        r.headers['Permissions-Policy']='geolocation=(), camera=(self), microphone=(self)'
        r.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; media-src 'self' blob:; connect-src 'self' https://*.googleapis.com https://*.firebaseinstallations.googleapis.com https://fcmregistrations.googleapis.com; frame-ancestors 'none'; base-uri 'self'; object-src 'none'"
        if request.path.startswith('/api/'): r.headers['Cache-Control']='no-store'
        return r
    @app.errorhandler(HTTPException)
    def http_error(e): return jsonify(error=e.description), e.code
    @app.errorhandler(IntegrityError)
    def conflict(e):
        db.session.rollback(); return jsonify(error='Конфликт записи. Повтори запрос с тем же ключом.'),409
    @app.errorhandler(Exception)
    def unexpected(e):
        db.session.rollback()
        app.logger.error('request_failed type=%s', type(e).__name__)
        return jsonify(error='Внутренняя ошибка сервера. Повтори позже.'),500
    from .api import api
    from . import releases
    app.register_blueprint(api,url_prefix='/api/v1')
    from .cli import register_cli
    register_cli(app)
    @app.get('/firebase-config.json')
    def firebase_config(): return jsonify(json.loads(os.getenv('FIREBASE_WEB_CONFIG','{}')))
    @app.get('/')
    @app.get('/admin')
    def index(): return send_from_directory(app.config['WEB_ROOT'],'index.html')
    @app.get('/<path:path>')
    def static(path): return send_from_directory(app.config['WEB_ROOT'],path)
    return app

def limit(scope, maximum=10, seconds=300):
    # Database-backed and atomic on both PostgreSQL and SQLite. Commit before endpoint work.
    from sqlalchemy.dialects.postgresql import insert as pg_insert
    from sqlalchemy.dialects.sqlite import insert as sq_insert
    from sqlalchemy import case
    key=digest(scope)
    insert=pg_insert if db.engine.dialect.name=='postgresql' else sq_insert
    stmt=insert(Rate).values(id=key,count=1,until=now()+seconds)
    stmt=stmt.on_conflict_do_update(index_elements=['id'],set_={
        'count':case((Rate.until<=now(),1),else_=Rate.count+1),
        'until':case((Rate.until<=now(),now()+seconds),else_=Rate.until)})
    db.session.execute(stmt); db.session.commit()
    from flask import abort
    if db.session.get(Rate,key).count>maximum: abort(429,'Слишком много попыток. Подожди немного.')

"""Durable PostgreSQL outbox. One worker, leases survive crashes; at-least-once delivery."""
import os, random, time
from pathlib import Path
from flask import current_app
from sqlalchemy import select, or_
from .models import *
from .api import event

def send_push(ins,data,dry_run=False):
    if not os.getenv('GOOGLE_APPLICATION_CREDENTIALS'): raise RuntimeError('FCM_NOT_CONFIGURED')
    import firebase_admin
    from firebase_admin import messaging
    if not firebase_admin._apps: firebase_admin.initialize_app()
    # A normal-priority sync signal. The native app posts one deduplicated notification.
    msg=messaging.Message(fid=ins.fid,data=data,android=messaging.AndroidConfig(priority='normal',ttl=300),
        webpush=messaging.WebpushConfig(headers={'TTL':'300'}))
    return messaging.send(msg,dry_run=dry_run)

def tick(sender=send_push):
    for m in db.session.scalars(select(Message).where(Message.dispatched==False,Message.send_at<=now(),Message.expires>now(),Message.cancelled==None).with_for_update(skip_locked=True).limit(100)):
        m.dispatched=True; event(m,'new')
    db.session.commit()
    jobs=list(db.session.scalars(select(Job).where(Job.state.in_(['pending','leased']),Job.due<=now()).with_for_update(skip_locked=True).limit(30)))
    ids=[j.id for j in jobs]
    for j in jobs: j.state='leased'; j.due=now()+120
    db.session.commit()
    for jid in ids:
        j=db.session.get(Job,jid); ins=db.session.get(Installation,j.installation_id)
        s=db.session.get(Session,ins.session_id) if ins else None
        m=db.session.get(Message,j.message_id)
        d=db.session.get(Device,s.device_id) if s and s.device_id else None
        membership_ok=not (s and s.user_id and m) or db.session.scalar(select(Membership.id).where(Membership.user_id==s.user_id,Membership.family_id==m.family_id)) is not None
        if not membership_ok or not s or s.expires<=now() or (d and d.revoked) or (m and (m.expires<=now() or (m.cancelled and j.kind=='new'))):
            j.state='skipped'; db.session.commit(); continue
        try:
            sender(ins,dict(type=j.kind,message_id=j.message_id,event_id=j.event_id,version='1'))
            j.state='sent'; j.error=None
        except Exception as exc:
            j.attempts+=1; j.error=type(exc).__name__  # no payloads, credentials or exception text
            j.state='failed' if j.attempts>=8 else 'pending'
            j.due=now()+min(3600,2**j.attempts*15)+random.randint(0,15)
        db.session.commit()
    for a in db.session.scalars(select(Attachment).where(Attachment.expires<=now())):
        (Path(current_app.config['MEDIA_ROOT'])/a.id).unlink(missing_ok=True)
    cutoff=now()-current_app.config['RETENTION_DAYS']*86400
    stale=list(db.session.scalars(select(Message.id).where(Message.expires<cutoff).limit(200)))
    if stale:
        db.session.query(Job).filter(Job.message_id.in_(stale)).delete(synchronize_session=False)
        db.session.query(Reply).filter(Reply.message_id.in_(stale)).delete(synchronize_session=False)
        db.session.query(Event).filter(Event.message_id.in_(stale)).delete(synchronize_session=False)
        db.session.query(Message).filter(Message.id.in_(stale)).delete(synchronize_session=False)
    db.session.query(Pairing).filter(Pairing.expires<now()-7*86400).delete()
    db.session.query(Invite).filter(Invite.expires<now()-7*86400).delete()
    db.session.query(Audit).filter(Audit.created<now()-90*86400).delete()
    db.session.query(Rate).filter(Rate.until<now()-86400).delete(); db.session.commit()

def run():
    from . import create_app
    app=create_app()
    with app.app_context():
        while True:
            try: tick()
            except Exception:
                db.session.rollback(); app.logger.error('worker_tick_failed')
            time.sleep(5)
if __name__=='__main__': run()

"""Release verification fails closed if the Android tools or scanner are absent."""
import os,re,subprocess,hashlib
from pathlib import Path
from flask import request,current_app,jsonify,abort,g,send_file
from sqlalchemy import select
from .api import api,auth,admin,body,string,number,audit,limit,actor
from .models import *

def command(args): return subprocess.run(args,capture_output=True,text=True,timeout=90,check=True).stdout

@api.post('/admin/releases/upload')
@auth
def upload_release():
    admin(trusted=True); limit('release:'+actor(),5,3600)
    channel=request.form.get('channel')
    if channel not in ('debug','release'): abort(400)
    apk=request.files.get('file')
    if not apk: abort(400)
    rid=uid(); path=Path(current_app.config['MEDIA_ROOT'])/(rid+'.apk'); apk.save(path)
    try:
        if path.stat().st_size>95*1024*1024: raise ValueError()
        command(['clamscan','--no-summary',str(path)])
        result=command(['apksigner','verify','--print-certs',str(path)])
        cert=re.search(r'Signer #1 certificate SHA-256 digest: ([a-fA-F0-9]+)',result).group(1).lower()
        expected=os.environ.get('APK_CERT_'+channel.upper(),'').lower()
        if not expected or cert!=expected: raise ValueError('certificate')
        package=command(['aapt','dump','badging',str(path)]).splitlines()[0]
        appid=re.search(r"name='([^']+)'",package).group(1)
        if appid!='fun.markol.kuizfamily': raise ValueError('package')
        vc=int(re.search(r"versionCode='(\d+)'",package).group(1)); vn=re.search(r"versionName='([^']+)'",package).group(1)
        old=db.session.scalar(select(Release).where(Release.channel==channel).order_by(Release.version_code.desc()))
        if old and vc<=old.version_code: raise ValueError('version')
    except (OSError,ValueError,AttributeError,subprocess.SubprocessError):
        path.unlink(missing_ok=True); abort(400,'APK отклонён: проверь сканер, aapt, apksigner, пакет, сертификат и versionCode')
    rel=Release(id=rid,channel=channel,version_code=vc,version_name=vn,cert=cert,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),size=path.stat().st_size)
    db.session.add(rel); audit('release.upload',rid); db.session.commit()
    return jsonify(id=rid,version_code=vc,version_name=vn,cert=cert,sha256=rel.sha256,size=rel.size),201

@api.post('/admin/releases/<rid>/publish')
@auth
def publish_release(rid):
    admin(trusted=True); x=body(); r=db.session.get(Release,rid)
    if not r: abort(404)
    r.notes=string(x,'notes',4000); r.rollout=number(x,'rollout',100,1,100); r.advisory=bool(x.get('advisory')); r.published=True
    audit('release.publish',rid); db.session.commit(); return jsonify(ok=True)

@api.post('/admin/releases/<rid>/revoke')
@auth
def revoke_release(rid):
    admin(trusted=True); r=db.session.get(Release,rid)
    if not r: abort(404)
    r.published=False; audit('release.revoke',rid); db.session.commit(); return jsonify(ok=True)

@api.get('/releases/current')
@auth
def current_release():
    ch=request.args.get('channel','release')
    rows=db.session.scalars(select(Release).where(Release.channel==ch,Release.published==True).order_by(Release.version_code.desc()))
    bucket=int(hashlib.sha256(actor().encode()).hexdigest()[:8],16)%100
    r=next((r for r in rows if bucket<r.rollout),None)
    return jsonify(release=None if not r else dict(id=r.id,version_code=r.version_code,version_name=r.version_name,sha256=r.sha256,notes=r.notes,advisory=r.advisory,url='/api/v1/releases/'+r.id+'/apk'))

@api.get('/releases/<rid>/apk')
@auth
def release_download(rid):
    r=db.session.get(Release,rid)
    if not r or not r.published: abort(404)
    return send_file(Path(current_app.config['MEDIA_ROOT'])/(rid+'.apk'),mimetype='application/vnd.android.package-archive',as_attachment=True,download_name='KuizFamily.apk')

import os, smtplib
from email.message import EmailMessage
from flask import current_app, abort

def send_link(email, token, purpose):
    host=os.getenv('SMTP_HOST')
    if not host: abort(503,'Отправка почты не настроена. Администратор должен настроить SMTP.')
    msg=EmailMessage(); msg['From']=os.environ['SMTP_FROM']; msg['To']=email
    msg['Subject']='Kuiz Family — приглашение' if purpose=='invite' else 'Kuiz Family — восстановление доступа'
    msg.set_content('Открой ссылку и введи свой email. Ссылка одноразовая:\n'+current_app.config['PUBLIC_ORIGIN']+'/#'+purpose+'='+token)
    with smtplib.SMTP(host,int(os.getenv('SMTP_PORT','587')),timeout=15) as s:
        s.starttls()
        if os.getenv('SMTP_USER'): s.login(os.environ['SMTP_USER'],os.environ['SMTP_PASSWORD'])
        s.send_message(msg)

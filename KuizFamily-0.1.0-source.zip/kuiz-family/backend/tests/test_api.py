import os,sys,uuid
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import pytest
from sqlalchemy import select
from kuiz import create_app,digest
from kuiz.models import *
from kuiz.api import ph

@pytest.fixture
def app(tmp_path):
    a=create_app({'TESTING':True,'SQLALCHEMY_DATABASE_URI':os.getenv('TEST_DATABASE_URL','sqlite:///'+str(tmp_path/'test.db')),'COOKIE_SECURE':False,'MEDIA_ROOT':str(tmp_path/'media')})
    with a.app_context(): db.drop_all();db.create_all()
    yield a

@pytest.fixture
def setup(app):
    with app.app_context():
        u=User(id=uid(),email='a@example.test',name='Родитель',password=ph.hash('correct-password'),admin=True)
        v=User(id=uid(),email='b@example.test',name='Другая семья',password=ph.hash('correct-password'))
        db.session.add_all([u,v]);db.session.commit()
    a=app.test_client();b=app.test_client()
    ra=a.post('/api/v1/auth/login',json={'email':'a@example.test','password':'correct-password'});rb=b.post('/api/v1/auth/login',json={'email':'b@example.test','password':'correct-password'})
    ah={'X-CSRF-Token':ra.json['csrf']};bh={'X-CSRF-Token':rb.json['csrf']}
    assert a.post('/api/v1/admin/devices/trust',json={'password':'correct-password','name':'Test browser'},headers=ah).status_code==200
    f=a.post('/api/v1/families',json={'name':'Наш дом'},headers=ah).json['id']
    f2=b.post('/api/v1/families',json={'name':'Другой дом'},headers=bh).json['id']
    child=app.test_client();p=child.post('/api/v1/pairings',json={'name':'Планшет'}).json
    r=a.post('/api/v1/pairings/confirm',json={'code':p['code'],'family_id':f,'confirm':True},headers=ah)
    assert r.status_code==201,r.json
    d=r.json['id'];claim=child.post('/api/v1/pairings/'+p['id']+'/claim',json={'secret':p['secret']})
    assert claim.status_code==200,claim.json
    ch={'Authorization':'Bearer '+claim.json['token']}
    return a,b,child,ah,bh,ch,f,f2,d,p

def send(s,**kw):
    a,b,c,ah,bh,ch,f,f2,d,p=s
    return a.post('/api/v1/messages',json={'device_id':d,'text':'Пора домой','key':str(uuid.uuid4()),**kw},headers=ah)

def test_vertical_slice_and_dedupe(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    m=send(setup,key='same');assert m.status_code==201,m.json
    assert m.json['status']=='saved'
    assert send(setup,key='same').json['id']==m.json['id']
    mid=m.json['id'];path='/api/v1/messages/'+mid
    assert c.get('/api/v1/messages',headers=ch).json['items'][0]['id']==mid
    for kind in ['delivered','opened','confirmed','delivered']:
        r=c.post(path+'/events',json={'kind':kind},headers=ch);assert r.status_code==200,r.json
    assert a.get(path,headers=ah).json['status']=='confirmed'
    r=c.post(path+'/reply',json={'text':'Уже иду','key':'r1'},headers=ch);assert r.status_code==201
    assert c.post(path+'/reply',json={'text':'Уже иду','key':'r1'},headers=ch).status_code==200
    assert len(a.get(path).json['replies'])==1

def test_family_isolation_and_admin_has_no_implicit_access(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    mid=send(setup).json['id']
    assert b.get('/api/v1/messages/'+mid).status_code==404
    assert b.post('/api/v1/messages/'+mid+'/reply',json={'text':'x','key':'x'},headers=bh).status_code==404
    assert c.get('/api/v1/admin/health',headers=ch).status_code==403
    assert b.get('/api/v1/admin/health').status_code==403
    assert a.get('/api/v1/admin/health').status_code==200

def test_pairing_replay_and_secret(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    assert c.post('/api/v1/pairings/'+p['id']+'/claim',json={'secret':p['secret']}).status_code==400
    assert b.post('/api/v1/pairings/confirm',json={'code':p['code'],'family_id':f2,'confirm':True},headers=bh).status_code==400
    q=c.post('/api/v1/pairings',json={'name':'Other'}).json
    assert c.post('/api/v1/pairings/'+q['id']+'/claim',json={'secret':'wrong'}).status_code==400

def test_csrf_and_origin(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    assert a.post('/api/v1/families',json={'name':'x'}).status_code==403
    assert a.post('/api/v1/families',json={'name':'x'},headers={**ah,'Origin':'https://evil.example'}).status_code==403

def test_cancel_expiry_scheduled(setup,app):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    m=send(setup).json['id']
    assert a.post('/api/v1/messages/'+m+'/cancel',json={},headers=ah).status_code==200
    assert c.post('/api/v1/messages/'+m+'/events',json={'kind':'opened'},headers=ch).status_code==409
    m=send(setup).json['id']
    with app.app_context(): db.session.get(Message,m).expires=now()-1;db.session.commit()
    assert c.post('/api/v1/messages/'+m+'/events',json={'kind':'confirmed'},headers=ch).status_code==409
    scheduled=send(setup,send_at=now()+3600).json
    assert scheduled['status']=='scheduled'
    assert scheduled['id'] not in [m['id'] for m in c.get('/api/v1/messages',headers=ch).json['items']]

def test_parent_cannot_fake_child_ack(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    m=send(setup).json['id']
    assert a.post('/api/v1/messages/'+m+'/events',json={'kind':'delivered'},headers=ah).status_code==403

def test_pin_rate_limit(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    assert a.post('/api/v1/families/'+f+'/pin',json={'password':'correct-password','pin':'123456'},headers=ah).status_code==200
    for _ in range(5): assert c.post('/api/v1/parent-access',json={'pin':'000000'},headers=ch).status_code==403
    assert c.post('/api/v1/parent-access',json={'pin':'123456'},headers=ch).status_code==429

def test_revoke(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    assert a.post('/api/v1/devices/'+d+'/revoke',json={'password':'correct-password'},headers=ah).status_code==200
    assert c.get('/api/v1/me',headers=ch).status_code==401

def test_outbox_fcm_is_not_delivery(setup,app):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    c.post('/api/v1/push/register',json={'fid':'fake-fid-test','platform':'android'},headers=ch)
    m=send(setup).json['id'];calls=[]
    from kuiz.worker import tick
    with app.app_context():
        tick(sender=lambda ins,data: calls.append(data))
        assert db.session.get(Message,m).delivered is None
        assert db.session.query(Job).filter_by(state='sent').count()==1
    assert len(calls)==1 and 'text' not in calls[0]

def test_failed_push_is_durable(setup,app):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    c.post('/api/v1/push/register',json={'fid':'fake','platform':'android'},headers=ch);send(setup)
    from kuiz.worker import tick
    def broken(*args):raise RuntimeError('secret must not be logged')
    with app.app_context():
        tick(sender=broken);j=db.session.scalar(select(Job));assert j.state=='pending' and j.attempts==1 and j.error=='RuntimeError'

def test_invites_single_use(app):
    with app.app_context(): db.session.add(Invite(id=digest('test-token'),email='new@example.test',expires=now()+60));db.session.commit()
    c=app.test_client();data={'email':'new@example.test','password':'strong-password','name':'Имя','token':'test-token'}
    assert c.post('/api/v1/auth/invites/redeem',json=data).status_code==201
    assert c.post('/api/v1/auth/invites/redeem',json=data).status_code==400

def test_unauthenticated_and_validation(app,setup):
    assert app.test_client().get('/api/v1/messages').status_code==401
    assert send(setup,priority=9).status_code==400
    assert send(setup,text='').status_code==400

def test_child_first_message(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    r=c.post('/api/v1/messages',json={'text':'Можно к другу?','key':'child1','device_id':d},headers=ch)
    assert r.status_code==201 and r.json['direction']=='to_parent'
    assert a.get('/api/v1/messages').json['items'][0]['text']=='Можно к другу?'

def test_push_registration_ownership(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    assert c.post('/api/v1/push/register',json={'fid':'own','platform':'android'},headers=ch).status_code==200
    assert b.post('/api/v1/push/register',json={'fid':'own','platform':'web'},headers=bh).status_code==409

def test_apk_fail_closed(setup):
    import io
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    r=a.post('/api/v1/admin/releases/upload',data={'channel':'debug','file':(io.BytesIO(b'not an apk'),'evil.apk')},headers=ah)
    assert r.status_code==400

def test_valid_media_and_family_permissions(setup,app,tmp_path):
    import subprocess,io
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    path=tmp_path/'sound.ogg'
    subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','sine=frequency=440:duration=1','-c:a','libopus',str(path)],check=True)
    r=a.post('/api/v1/attachments',data={'family_id':f,'key':'media-test','file':(io.BytesIO(path.read_bytes()),'sound.ogg')},headers=ah)
    assert r.status_code==201,r.json
    aid=r.json['id']
    assert b.get('/api/v1/attachments/'+aid).status_code==404
    assert c.get('/api/v1/attachments/'+aid,headers=ch).status_code==404
    assert send(setup,attachment_id=aid).status_code==201
    assert c.get('/api/v1/attachments/'+aid,headers=ch).status_code==200
    assert a.delete('/api/v1/attachments/'+aid,headers=ah).status_code==200
    assert c.get('/api/v1/attachments/'+aid,headers=ch).status_code==404

def test_fake_media_rejected(setup):
    import io
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    r=a.post('/api/v1/attachments',data={'family_id':f,'key':'media-test','file':(io.BytesIO(b'<script>evil</script>'),'voice.mp4')},headers=ah)
    assert r.status_code==400

def test_scheduled_worker_and_crash_lease(setup,app):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    c.post('/api/v1/push/register',json={'fid':'scheduled','platform':'android'},headers=ch)
    m=send(setup,send_at=now()+3600).json['id']
    from kuiz.worker import tick
    calls=[]
    with app.app_context():
        db.session.get(Message,m).send_at=now()-1;db.session.commit();tick(sender=lambda *args:calls.append(args))
        assert len(calls)==1
        j=db.session.scalar(select(Job));j.state='leased';j.due=now()-1;db.session.commit()
        tick(sender=lambda *args:calls.append(args));assert len(calls)==2 # at-least-once; client dedupes event_id

def test_revoked_admin_grant_blocks_publication(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    grant=a.get('/api/v1/admin/devices').json['items'][0]['id']
    assert a.post('/api/v1/admin/devices/'+grant+'/revoke',json={},headers=ah).status_code==200
    assert a.post('/api/v1/admin/releases/'+str(uuid.uuid4())+'/publish',json={'notes':'x'},headers=ah).status_code==403

def test_expired_pairing(app):
    c=app.test_client();p=c.post('/api/v1/pairings',json={'name':'Tablet'}).json
    with app.app_context(): db.session.get(Pairing,p['id']).expires=0;db.session.commit()
    assert c.post('/api/v1/pairings/'+p['id']+'/claim',json={'secret':p['secret']}).status_code==400

def test_session_logout_revokes_push(setup,app):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    a.post('/api/v1/push/register',json={'fid':'parent','platform':'web'},headers=ah)
    assert a.post('/api/v1/auth/logout',json={},headers=ah).status_code==200
    assert a.get('/api/v1/me').status_code==401
    with app.app_context(): assert db.session.scalar(select(Installation).where(Installation.fid=='parent')) is None

def test_refresh_rotates_child_session(setup):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    r=c.post('/api/v1/auth/refresh',json={},headers=ch)
    assert r.status_code==200
    assert c.get('/api/v1/me',headers=ch).status_code==401
    assert c.get('/api/v1/me',headers={'Authorization':'Bearer '+r.json['token']}).status_code==200

def test_media_upload_idempotency(setup,tmp_path):
    import subprocess,io
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    path=tmp_path/'sound.ogg';subprocess.run(['ffmpeg','-v','error','-f','lavfi','-i','sine=duration=1','-c:a','libopus',str(path)],check=True)
    def upload():return a.post('/api/v1/attachments',data={'family_id':f,'key':'upload-repeat','file':(io.BytesIO(path.read_bytes()),'sound.ogg')},headers=ah)
    first=upload();second=upload();assert first.json['id']==second.json['id']

def test_cursor_preserves_same_second_messages(setup,app):
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    with app.app_context():
        author=db.session.scalar(select(User.id).where(User.email=='a@example.test'))
        for i in range(205): db.session.add(Message(family_id=f,device_id=d,author=author,key='page'+str(i),text=str(i),created=now(),expires=now()+3600))
        db.session.commit()
    first=a.get('/api/v1/messages').json;assert len(first['items'])==200
    second=a.get('/api/v1/messages',query_string={'cursor':first['next_cursor']}).json
    assert len(second['items'])==5
    assert len({m['id'] for m in first['items']+second['items']})==205

def test_retention_deletes_old_content(setup,app):
    from kuiz.worker import tick
    mid=send(setup).json['id']
    with app.app_context():
        db.session.get(Message,mid).expires=now()-31*86400;db.session.commit()
        tick(sender=lambda *args:None)
        assert db.session.get(Message,mid) is None

def test_cancel_before_push(setup,app):
    from kuiz.worker import tick
    a,b,c,ah,bh,ch,f,f2,d,p=setup
    c.post('/api/v1/push/register',json={'fid':'cancel-test','platform':'android'},headers=ch)
    mid=send(setup).json['id'];a.post('/api/v1/messages/'+mid+'/cancel',json={},headers=ah);calls=[]
    with app.app_context():tick(sender=lambda *args:calls.append(args))
    assert len(calls)==1 and calls[0][1]['type']=='cancelled'

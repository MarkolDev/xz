import {initializeApp} from 'firebase/app';
import {getMessaging,register,onRegistered,isSupported} from 'firebase/messaging';
export async function enablePush(api){
 if(!await isSupported())throw new Error('Этот браузер не поддерживает Web Push');
 const config=await fetch('/firebase-config.json').then(r=>r.json());
 if(!config.apiKey||!config.vapidKey)throw new Error('Firebase ещё не настроен администратором');
 if(await Notification.requestPermission()!=='granted')throw new Error('Разрешение на уведомления не выдано');
 const sw=await navigator.serviceWorker.register('/firebase-messaging-sw.js',{type:'module'});
 const messaging=getMessaging(initializeApp(config));
 onRegistered(messaging,fid=>api('/push/register',{fid,platform:'web'}));
 await register(messaging,{vapidKey:config.vapidKey,serviceWorkerRegistration:sw});
}

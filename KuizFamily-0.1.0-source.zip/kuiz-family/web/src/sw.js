import {initializeApp} from 'firebase/app';
import {getMessaging,onBackgroundMessage} from 'firebase/messaging/sw';
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(clients.openWindow(self.location.origin+'/'))});
const config=await fetch('/firebase-config.json').then(r=>r.json());
if(config.apiKey){const m=getMessaging(initializeApp(config));onBackgroundMessage(m,async payload=>{const tag=payload.data?.event_id;if(!tag)return;const cache=await caches.open('kuiz-push-dedupe');const key=new Request(self.location.origin+'/push-seen/'+encodeURIComponent(tag));if(await cache.match(key))return;await cache.put(key,new Response('1'));const keys=await cache.keys();if(keys.length>200)await cache.delete(keys[0]);await self.registration.showNotification('Kuiz Family',{body:'В семье новое событие. Открой приложение.',tag:'kuiz-family',renotify:false})})}

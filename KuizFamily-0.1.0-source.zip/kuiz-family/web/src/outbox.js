let db;
export function openOutbox(){return new Promise((resolve,reject)=>{let r=indexedDB.open('kuiz-family',1);r.onupgradeneeded=()=>r.result.createObjectStore('outbox',{keyPath:'id'});r.onsuccess=()=>{db=r.result;resolve()};r.onerror=()=>reject(r.error)})}
function transaction(mode,fn){return new Promise((resolve,reject)=>{const t=db.transaction('outbox',mode),r=fn(t.objectStore('outbox'));t.oncomplete=()=>resolve(r.result);t.onerror=()=>reject(t.error)})}
export const put=x=>transaction('readwrite',s=>s.put(x));
export const all=()=>transaction('readonly',s=>s.getAll());
export const del=id=>transaction('readwrite',s=>s.delete(id));

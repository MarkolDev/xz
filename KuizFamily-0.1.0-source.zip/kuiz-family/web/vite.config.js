import {defineConfig} from 'vite';
export default defineConfig({build:{target:'es2022',rollupOptions:{input:{main:'index.html','firebase-messaging-sw':'src/sw.js'},output:{entryFileNames:chunk=>chunk.name==='firebase-messaging-sw'?'firebase-messaging-sw.js':'assets/[name]-[hash].js'}}}});

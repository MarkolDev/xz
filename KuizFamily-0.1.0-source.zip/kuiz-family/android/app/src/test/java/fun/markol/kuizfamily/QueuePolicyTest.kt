package `fun`.markol.kuizfamily
import org.junit.Assert.*
import org.junit.Test
class QueuePolicyTest {
 private fun row(status:String="saved",expires:Long=200)=CachedMessage("id","{}",2,10,expires,status)
 @Test fun expiredMessagesNeverInterrupt(){assertFalse(QueuePolicy.live(row(expires=99),100))}
 @Test fun confirmationAndCancellationStopRepeats(){for(s in listOf("confirmed","replied","cancelled","expired"))assertFalse(QueuePolicy.live(row(s),100))}
 @Test fun importantIsBounded(){assertEquals(3,QueuePolicy.maxShows(2));assertEquals(1L,QueuePolicy.delaySeconds(2));assertEquals(1,QueuePolicy.maxShows(0))}
}

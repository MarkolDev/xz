package `fun`.markol.kuizfamily
import android.content.Context
import android.webkit.CookieManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiError(val code:Int,message:String):IOException(message)
class Api(private val context:Context){
 val vault=Vault(context)
 private val client=OkHttpClient.Builder().callTimeout(25,TimeUnit.SECONDS).connectTimeout(8,TimeUnit.SECONDS).followRedirects(false).build()
 private val origins=listOf("https://kfml.markol.fun","https://prkfml.markol.fun")
 private var preferred=0
 suspend fun call(path:String,data:JSONObject?=null):JSONObject=withContext(Dispatchers.IO){
  execute(path,data?.toString()?.toRequestBody("application/json".toMediaType())).use{r->val text=r.body?.string()?:"{}";if(!r.isSuccessful)throw ApiError(r.code,runCatching{JSONObject(text).optString("error")}.getOrDefault("Ошибка сервера"));JSONObject(text)}
 }
 private fun execute(path:String,body:RequestBody?=null):Response {
  var failure:IOException?=null
  // Parent cookies stay on canonical origin; never copied to fallback host.
  val routes=if(vault.role=="parent")listOf(0) else listOf(preferred,1-preferred)
  for(i in routes){try{
   val b=Request.Builder().url(origins[i]+"/api/v1"+path)
   if(vault.role=="parent"){
    b.header("Cookie",CookieManager.getInstance().getCookie(origins[0])?:"")
    if(body!=null){val me=client.newCall(Request.Builder().url(origins[0]+"/api/v1/me").header("Cookie",CookieManager.getInstance().getCookie(origins[0])?:"").build()).execute().use{JSONObject(it.body?.string()?:"{}")};b.header("X-CSRF-Token",me.optString("csrf"))}
   }else if(vault.token.isNotEmpty()) b.header("Authorization","Bearer "+vault.token)
   if(body!=null)b.post(body)
   val r=client.newCall(b.build()).execute()
   if(r.code>=500){r.close();failure=IOException("Маршрут недоступен");continue}
   preferred=i;return r
  }catch(e:IOException){failure=e}}
  throw failure?:IOException("Нет связи с обоими маршрутами")
 }
 suspend fun upload(file:File,family:String,key:String):String=withContext(Dispatchers.IO){
  val b=MultipartBody.Builder().setType(MultipartBody.FORM).addFormDataPart("family_id",family).addFormDataPart("key",key).addFormDataPart("file",file.name,file.asRequestBody("application/octet-stream".toMediaType())).build()
  execute("/attachments",b).use{r->val o=JSONObject(r.body?.string()?:"{}");if(!r.isSuccessful)throw ApiError(r.code,o.optString("error"));o.getString("id")}
 }
 suspend fun download(path:String,to:File)=withContext(Dispatchers.IO){execute(path).use{r->if(!r.isSuccessful)throw ApiError(r.code,"Не удалось скачать");r.body!!.byteStream().use{input->to.outputStream().use{input.copyTo(it)}}}}
}

package `fun`.markol.kuizfamily

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.webkit.*
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessaging
import com.google.zxing.BarcodeFormat
import com.google.zxing.MultiFormatWriter
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.util.UUID

class MainActivity:ComponentActivity(){override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);enableEdgeToEdge();setContent{FamilyUI()}}}
@Composable fun FamilyUI(){
 val ctx=LocalContext.current;val vault=remember{Vault(ctx)};var theme by remember{mutableStateOf(vault.theme)}
 val dark=if(theme=="auto")isSystemInDarkTheme()else theme=="dark"
 val colors=if(Build.VERSION.SDK_INT>=31){if(dark)dynamicDarkColorScheme(ctx)else dynamicLightColorScheme(ctx)}else if(dark)darkColorScheme()else lightColorScheme(primary=Color(0xff49672d),primaryContainer=Color(0xffc9eda4))
 var role by remember{mutableStateOf(vault.role)};var bound by remember{mutableStateOf(vault.token.isNotEmpty())}
 MaterialTheme(colorScheme=colors){Surface(Modifier.fillMaxSize()){Scaffold{padding->Box(Modifier.padding(padding).fillMaxSize()){
 if(role=="parent")ParentScreen(onExit={vault.role="";role=""})
 else if(role=="child"&&bound)ChildScreen(theme,{theme=it;vault.theme=it})
 else if(role=="child")PairingScreen(onDone={bound=true;role="child"},onBack={vault.role="";role=""})
 else Column(Modifier.fillMaxSize().padding(28.dp),verticalArrangement=Arrangement.Center,horizontalAlignment=Alignment.CenterHorizontally){
 Text("Kuiz Family",style=MaterialTheme.typography.displaySmall);Spacer(Modifier.height(20.dp));Text("Семья рядом",style=MaterialTheme.typography.headlineSmall);Text("Короткие сообщения и забота — без слежки.",Modifier.padding(vertical=24.dp));
 Button(onClick={vault.role="parent";role="parent"},Modifier.fillMaxWidth().heightIn(min=56.dp)){Text("Я родитель")};Spacer(Modifier.height(16.dp));FilledTonalButton(onClick={vault.role="child";role="child"},Modifier.fillMaxWidth().heightIn(min=56.dp)){Text("Я ребёнок")}
 }
 }}}}
}
@Composable fun PermissionButton(){
 val ctx=LocalContext.current;var note by remember{mutableStateOf("")}
 val launcher=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){ok->note=if(ok)"Уведомления разрешены" else "Можно читать сообщения в приложении"}
 Column{OutlinedButton(onClick={if(Build.VERSION.SDK_INT>=33)launcher.launch(Manifest.permission.POST_NOTIFICATIONS);if(FirebaseApp.getApps(ctx).isNotEmpty())FirebaseMessaging.getInstance().register()}){Text("Разрешить уведомления")};if(note.isNotEmpty())Text(note)}
}
@Composable fun PairingScreen(onDone:()->Unit,onBack:()->Unit){
 val ctx=LocalContext.current;val api=remember{Api(ctx)};val scope=rememberCoroutineScope();var name by remember{mutableStateOf("Мой планшет")};var pairing by remember{mutableStateOf<JSONObject?>(null)};var error by remember{mutableStateOf("")};var paired by remember{mutableStateOf(false)};var remaining by remember{mutableLongStateOf(0)}
 if(paired){ChildScreen("auto",{});return}
 LaunchedEffect(pairing){val p=pairing?:return@LaunchedEffect
  while(isActive){remaining=p.getLong("expires")-System.currentTimeMillis()/1000;if(remaining<=0){error="Код истёк. Создай новый.";break}
   try{val r=api.call("/pairings/${p.getString("id")}/claim",JSONObject().put("secret",p.getString("secret")));if(r.has("token")){api.vault.token=r.getString("token");paired=true;SyncWorker.enqueue(ctx);onDone();break}}catch(e:Exception){error=e.message?:"Нет связи"};delay(3000)
  }
 }
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),verticalArrangement=Arrangement.spacedBy(16.dp),horizontalAlignment=Alignment.CenterHorizontally){
 Text("Подключимся к семье",style=MaterialTheme.typography.headlineMedium);Text("Взрослые смогут писать тебе и видеть подтверждения. Приложение не собирает местоположение и не следит за другими приложениями.")
 OutlinedTextField(name,{name=it},label={Text("Название устройства")},modifier=Modifier.fillMaxWidth());PermissionButton()
 Button(onClick={scope.launch{try{pairing=api.call("/pairings",JSONObject().put("name",name));error=""}catch(e:Exception){error=e.message?:"Нет связи"}}}){Text(if(pairing==null)"Подключить к семье" else "Новый код")}
 pairing?.let{p->val code=p.getString("code");val bitmap=remember(code){val matrix=MultiFormatWriter().encode("kuizfamily:pair:$code",BarcodeFormat.QR_CODE,400,400);android.graphics.Bitmap.createBitmap(400,400,android.graphics.Bitmap.Config.ARGB_8888).apply{for(y in 0 until 400)for(x in 0 until 400)setPixel(x,y,if(matrix[x,y])android.graphics.Color.BLACK else android.graphics.Color.WHITE)}}
 Image(bitmap.asImageBitmap(),contentDescription="QR-код для привязки: $code",modifier=Modifier.size(220.dp));Text(code,style=MaterialTheme.typography.displaySmall);Text("Действует ещё ${remaining.coerceAtLeast(0)} сек.");Text("Попроси взрослого ввести код в разделе «Подключить планшет».")}
 if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
 TextButton(onClick={scope.launch{pairing?.let{runCatching{api.call("/pairings/${it.getString("id")}/cancel",JSONObject().put("secret",it.getString("secret")))}};onBack()}}){Text("Отмена")}
 }
}
@Composable fun ChildScreen(theme:String,onTheme:(String)->Unit){
 val ctx=LocalContext.current;val repo=remember{Repository(ctx)};val scope=rememberCoroutineScope();val rows by repo.dao.observe().collectAsState(initial=listOf());val count by repo.dao.count().collectAsState(initial=0)
 var error by remember{mutableStateOf("")};var currentId by remember{mutableStateOf((ctx as? Activity)?.intent?.getStringExtra("message_id"))};var composer by remember{mutableStateOf(false)};var settings by remember{mutableStateOf(false)};var pin by remember{mutableStateOf(false)};var pinText by remember{mutableStateOf("")};var taps by remember{mutableIntStateOf(0)};var adultUntil by remember{mutableLongStateOf(0)};var clock by remember{mutableLongStateOf(System.currentTimeMillis()/1000)};var release by remember{mutableStateOf<JSONObject?>(null)}
 val lifecycle=LocalLifecycleOwner.current.lifecycle
 LaunchedEffect(Unit){lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED){launch{while(isActive){clock=System.currentTimeMillis()/1000;delay(1000)}};while(isActive){try{repo.sync();error=""}catch(e:Exception){error=if(e is ApiError&&e.code==401)"Доступ отозван или сессия истекла. Обратись к взрослому."else"Нет связи. Ответы сохраняются на устройстве."};delay(15000)}}}
 LaunchedEffect(rows,clock,settings,composer){if(!settings&&!composer&&currentId==null&&clock>adultUntil){QueuePolicy.next(rows,clock)?.let{currentId=it.id;repo.dao.save(it.copy(shown=it.shown+1));repo.event(it.id,"opened")}}}
 val current=rows.find{it.id==currentId}
 LaunchedEffect(current?.status,clock){if(current!=null&&!QueuePolicy.live(current,clock))currentId=null}
 fun close(repeat:Boolean=true){if(repeat)current?.let{m->ReminderWorker.afterDismiss(ctx,m);scope.launch{repo.dao.get(m.id)?.let{latest->repo.dao.save(latest.copy(nextShow=clock+QueuePolicy.delaySeconds(m.priority)))}}};currentId=null;composer=false}
 BackHandler(currentId!=null||settings||composer){if(settings)settings=false else close()}
 if(pin)AlertDialog(onDismissRequest={pin=false},title={Text("Доступ взрослого")},text={OutlinedTextField(pinText,{pinText=it},label={Text("Родительский PIN")},visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation())},confirmButton={TextButton(onClick={scope.launch{try{adultUntil=repo.api.call("/parent-access",JSONObject().put("pin",pinText)).getLong("until");pin=false;currentId=null;pinText=""}catch(e:Exception){error=e.message?:"Неверный PIN";pin=false}}}){Text("Подтвердить")}},dismissButton={TextButton(onClick={pin=false}){Text("Отмена")}})
 Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp).widthIn(max=900.dp),verticalArrangement=Arrangement.spacedBy(16.dp)){
 Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text("Kuiz Family",style=MaterialTheme.typography.titleLarge);TextButton(onClick={settings=!settings}){Text(if(settings)"Назад"else"Настройки")}}
 if(error.isNotEmpty())Card{Text(error,Modifier.padding(16.dp))};if(count>0)Text("В очереди отправки: $count",style=MaterialTheme.typography.labelLarge)
 if(settings){
 Text("Твоё устройство",style=MaterialTheme.typography.headlineMedium);val info=JSONObject(repo.vault.info);Text(info.optString("name","Планшет"));Text("Семья: "+info.optString("family_name"));Text("Взрослые: "+info.optJSONArray("adults")?.join(", "));PermissionButton()
 Text("Тема");Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){listOf("auto" to "Авто","light" to "Светлая","dark" to "Тёмная").forEach{(k,v)->FilterChip(selected=theme==k,onClick={onTheme(k)},label={Text(v)})}}
 var consent by remember{mutableStateOf(repo.vault.batteryConsent)};Row(verticalAlignment=Alignment.CenterVertically){Switch(consent,{consent=it;repo.vault.batteryConsent=it});Text("Показывать семье заряд батареи",Modifier.padding(start=12.dp))}
 Text("Версия ${BuildConfig.VERSION_NAME}. Для отвязки взрослый вводит пароль в своей панели. Выход из этого экрана всегда доступен.")
 OutlinedButton(onClick={scope.launch{try{release=repo.api.call("/releases/current?channel="+if(BuildConfig.DEBUG)"debug"else"release").optJSONObject("release");if(release==null)error="Новых обновлений нет"}catch(e:Exception){error=e.message?:"Ошибка проверки"}}}){Text("Проверить обновления")}
 }else if(composer){ReplyComposer(onSend={text,file->scope.launch{val payload=JSONObject().put("text",text).put("key",UUID.randomUUID().toString());val path=if(currentId!=null)"/messages/$currentId/reply"else"/messages";if(currentId==null)payload.put("device_id",JSONObject(repo.vault.info).getString("device_id"));repo.enqueue(path,payload,file);currentId?.let{id->repo.dao.get(id)?.let{repo.dao.save(it.copy(status="replied"))}};close(false)}},onCancel={composer=false})
 }else if(current!=null){
 val msg=JSONObject(current.json)
 Text("Доступ временно ограничен",Modifier.clickable{taps++;if(taps>=4){pin=true;taps=0}},style=MaterialTheme.typography.labelLarge)
 Text(msg.optString("sender_name","Семья")+" сообщает тебе",style=MaterialTheme.typography.headlineLarge);SuggestionChip(onClick={},label={Text(listOf("Мягко","Средне","Важно")[current.priority])});Text(msg.optString("text"),style=MaterialTheme.typography.headlineSmall)
 if(!msg.isNull("attachment_id"))MediaPlayback(msg.getString("attachment_id"))
 Button(onClick={composer=true},Modifier.fillMaxWidth()){Text("Ответить семье")}
 listOf("Уже иду","Через 5 минут","Можно ещё немного?","Позвони мне").forEach{text->OutlinedButton(onClick={scope.launch{repo.enqueue("/messages/${current.id}/reply",JSONObject().put("text",text).put("key",UUID.randomUUID().toString()));repo.dao.save(current.copy(status="replied"));close(false)}},Modifier.fillMaxWidth()){Text(text)}}
 FilledTonalButton(onClick={scope.launch{repo.event(current.id,"confirmed");close(false)}},Modifier.fillMaxWidth()){Text("Хорошо, выйти")}
 TextButton(onClick={close()}){Text("Закрыть без подтверждения")};TextButton(onClick={pin=true}){Text("Помощь / доступ взрослого")};TextButton(onClick={(ctx as? Activity)?.finish()}){Text("Выйти из приложения")}
 }else{
 val info=JSONObject(repo.vault.info);Text("Привет!",style=MaterialTheme.typography.displaySmall);Text("Ты на связи с семьёй "+info.optString("family_name"));Button(onClick={composer=true},Modifier.fillMaxWidth().heightIn(min=56.dp)){Text("Написать родителям")};Text("История",style=MaterialTheme.typography.headlineSmall)
 rows.forEach{m->val j=JSONObject(m.json);Card(onClick={currentId=m.id},Modifier.fillMaxWidth()){Column(Modifier.padding(20.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text(j.optString("text").ifEmpty{"Медиасообщение"},style=MaterialTheme.typography.titleMedium);Text(statusText(m.status));val replies=j.optJSONArray("replies");if(replies!=null)for(i in 0 until replies.length())Text("Ответ: "+replies.getJSONObject(i).optString("text"))}}}
 }
 }
 release?.let{r->AlertDialog(onDismissRequest={release=null},title={Text("Kuiz Family "+r.optString("version_name"))},text={Text(r.optString("notes"))},confirmButton={TextButton(onClick={scope.launch{try{val dir=File(ctx.cacheDir,"updates").apply{mkdirs()};val file=File(dir,"update.apk");repo.api.download(r.getString("url").removePrefix("/api/v1"),file);val sum=withContext(Dispatchers.IO){java.security.MessageDigest.getInstance("SHA-256").digest(file.readBytes()).joinToString(""){"%02x".format(it)}};check(sum==r.getString("sha256")){"Контрольная сумма не совпала"};val uri=FileProvider.getUriForFile(ctx,ctx.packageName+".files",file);ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION));release=null}catch(e:Exception){error=e.message?:"Не удалось установить";release=null}}}){Text("Скачать и установить")}},dismissButton={TextButton(onClick={release=null}){Text("Позже")}})}
}
fun statusText(s:String)=mapOf("saved" to "Сохранено на сервере","delivered" to "Доставлено","opened" to "Открыто","confirmed" to "Подтверждено","replied" to "Есть ответ","cancelled" to "Отменено","expired" to "Просрочено")[s]?:s

@Composable fun ReplyComposer(onSend:(String,File?)->Unit,onCancel:()->Unit){
 val ctx=LocalContext.current;var text by remember{mutableStateOf("")};var file by remember{mutableStateOf<File?>(null)};var recorder by remember{mutableStateOf<MediaRecorder?>(null)};var recording by remember{mutableStateOf(false)};var error by remember{mutableStateOf("")};var recordingFile by remember{mutableStateOf<File?>(null)}
 fun stop(){try{recorder?.stop();file=recordingFile}catch(_:Exception){error="Запись слишком короткая"}finally{recorder?.release();recorder=null;recording=false}}
 fun startAudio(){try{val f=File(File(ctx.filesDir,"recordings").apply{mkdirs()},UUID.randomUUID().toString()+".m4a");recordingFile=f;val r=if(Build.VERSION.SDK_INT>=31)MediaRecorder(ctx)else @Suppress("DEPRECATION") MediaRecorder();r.setAudioSource(MediaRecorder.AudioSource.MIC);r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);r.setOutputFile(f.absolutePath);r.setMaxDuration(90000);r.setOnInfoListener{_,what,_->if(what==MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED)stop()};r.prepare();r.start();recorder=r;recording=true;error=""}catch(e:Exception){error=e.message?:"Не удалось записать"}}
 val mic=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)startAudio()else error="Микрофон не разрешён. Можно ответить текстом."}
 val camera=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->if(r.resultCode==Activity.RESULT_OK){file=recordingFile}else error="Запись отменена"}
 fun startVideo(){try{val f=File(File(ctx.filesDir,"recordings").apply{mkdirs()},UUID.randomUUID().toString()+".mp4");recordingFile=f;val uri=FileProvider.getUriForFile(ctx,ctx.packageName+".files",f);camera.launch(Intent(android.provider.MediaStore.ACTION_VIDEO_CAPTURE).putExtra(android.provider.MediaStore.EXTRA_OUTPUT,uri).putExtra(android.provider.MediaStore.EXTRA_DURATION_LIMIT,90).putExtra(android.provider.MediaStore.EXTRA_VIDEO_QUALITY,0).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION))}catch(_:Exception){error="Нет приложения камеры. Ответь голосом или текстом."}}
 val cameraPermission=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){if(it)startVideo()else error="Камера не разрешена. Можно ответить текстом."}

 DisposableEffect(Unit){onDispose{recorder?.runCatching{stop();release()}}}
 Text("Ответить семье",style=MaterialTheme.typography.headlineMedium);OutlinedTextField(text,{text=it},label={Text("Сообщение")},modifier=Modifier.fillMaxWidth(),minLines=3)
 Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick={if(recording)stop()else if(ContextCompat.checkSelfPermission(ctx,Manifest.permission.RECORD_AUDIO)==PackageManager.PERMISSION_GRANTED)startAudio()else mic.launch(Manifest.permission.RECORD_AUDIO)}){Text(if(recording)"Остановить"else"Голос")};OutlinedButton(enabled=!recording,onClick={if(ContextCompat.checkSelfPermission(ctx,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED)startVideo()else cameraPermission.launch(Manifest.permission.CAMERA)}){Text("Кружочек")}}
 if(recording)Text("Идёт запись… максимум 90 секунд")
 file?.let{f->Text("Запись готова: ${f.length()/1024} КБ");AndroidView(factory={VideoView(it).apply{setVideoURI(Uri.fromFile(f));val controls=android.widget.MediaController(it);controls.setAnchorView(this);setMediaController(controls)}},modifier=Modifier.size(200.dp));TextButton(onClick={file=null}){Text("Удалить запись")}}
 if(error.isNotEmpty())Text(error,color=MaterialTheme.colorScheme.error)
 Button(enabled=!recording&&(text.isNotBlank()||file!=null),onClick={onSend(text,file)},modifier=Modifier.fillMaxWidth()){Text("Отправить")};TextButton(onClick=onCancel){Text("Назад")}
}
@Composable fun MediaPlayback(id:String){
 val ctx=LocalContext.current;val scope=rememberCoroutineScope();var local by remember(id){mutableStateOf<File?>(null)};var error by remember{mutableStateOf("")}
 LaunchedEffect(id){try{val f=File(ctx.cacheDir,id+".mp4");Api(ctx).download("/attachments/$id",f);local=f}catch(e:Exception){error="Запись недоступна без связи"}}
 local?.let{f->AndroidView(factory={c->VideoView(c).apply{setVideoURI(Uri.fromFile(f));val controls=android.widget.MediaController(c);controls.setAnchorView(this);setMediaController(controls)}},modifier=Modifier.size(240.dp).clip(CircleShape))};if(error.isNotEmpty())Text(error)
}
@Composable fun ParentScreen(onExit:()->Unit){
 val ctx=LocalContext.current;val vault=remember{Vault(ctx)};val scope=rememberCoroutineScope();var web by remember{mutableStateOf<WebView?>(null)};var request by remember{mutableStateOf<PermissionRequest?>(null)};var error by remember{mutableStateOf("")}
 val lifecycle=LocalLifecycleOwner.current.lifecycle
 LaunchedEffect(Unit){lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED){while(isActive){try{if(vault.fid.isNotEmpty())Api(ctx).call("/push/register",JSONObject().put("fid",vault.fid).put("platform","android"))}catch(_:Exception){};delay(30000)}}}
 val permissions=rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){grants->val req=request;if(req!=null){val allowed=req.resources.filter{r->(r==PermissionRequest.RESOURCE_AUDIO_CAPTURE&&grants[Manifest.permission.RECORD_AUDIO]==true)||(r==PermissionRequest.RESOURCE_VIDEO_CAPTURE&&grants[Manifest.permission.CAMERA]==true)};if(allowed.isNotEmpty())req.grant(allowed.toTypedArray())else req.deny()};request=null}
 BackHandler{if(web?.canGoBack()==true)web?.goBack()else onExit()}
 Column(Modifier.fillMaxSize()){
 Row(Modifier.padding(horizontal=12.dp),verticalAlignment=Alignment.CenterVertically){TextButton(onClick=onExit){Text("Выбор режима")};PermissionButton()}
 if(error.isNotEmpty())Text(error,Modifier.padding(12.dp))
 AndroidView(factory={c->WebView(c).apply{
  settings.javaScriptEnabled=true;settings.domStorageEnabled=true;settings.allowFileAccess=false;settings.allowContentAccess=false;settings.mixedContentMode=WebSettings.MIXED_CONTENT_NEVER_ALLOW;settings.userAgentString+=" KuizFamilyNative";CookieManager.getInstance().setAcceptThirdPartyCookies(this,false)
  webViewClient=object:WebViewClient(){override fun shouldOverrideUrlLoading(view:WebView?,r:WebResourceRequest):Boolean{return r.url.scheme!="https"||r.url.host!="kfml.markol.fun"}
   override fun onPageFinished(view:WebView?,url:String?){CookieManager.getInstance().flush();scope.launch{try{if(vault.fid.isNotEmpty())Api(ctx).call("/push/register",JSONObject().put("fid",vault.fid).put("platform","android"))}catch(_:Exception){}}}
  }
  webChromeClient=object:WebChromeClient(){override fun onPermissionRequest(req:PermissionRequest){if(req.origin.scheme!="https"||req.origin.host!="kfml.markol.fun"){req.deny();return};request=req;permissions.launch(arrayOf(Manifest.permission.RECORD_AUDIO,Manifest.permission.CAMERA))}}
  val target=(ctx as? Activity)?.intent?.getStringExtra("message_id");loadUrl("https://kfml.markol.fun"+(target?.let{"/#message="+Uri.encode(it)}?:""));web=this
 }},modifier=Modifier.weight(1f))
 }
 DisposableEffect(Unit){onDispose{web?.destroy()}}
}

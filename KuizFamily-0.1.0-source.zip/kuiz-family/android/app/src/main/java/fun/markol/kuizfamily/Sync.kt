package `fun`.markol.kuizfamily
import android.app.*
import android.content.*
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.work.*
import com.google.firebase.FirebaseApp
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject
import java.io.File
import java.util.UUID
import java.util.concurrent.TimeUnit

class FamilyApp:Application(){override fun onCreate(){super.onCreate();FirebaseApp.initializeApp(this);val nm=getSystemService(NotificationManager::class.java);nm.createNotificationChannel(NotificationChannel("family","Сообщения семьи",NotificationManager.IMPORTANCE_DEFAULT));SyncWorker.schedule(this)}}
class Repository(private val context:Context){
 val dao=Cache.get(context).dao();val api=Api(context);val vault=api.vault
 companion object {private val mutex=Mutex()}
 suspend fun enqueue(path:String,data:JSONObject,file:File?=null){
  val id=data.optString("key").ifEmpty{UUID.randomUUID().toString()};data.put("key",id)
  dao.queue(Pending(id,path,data.toString(),file?.absolutePath,JSONObject(vault.info).optString("family_id")));SyncWorker.enqueue(context)
 }
 suspend fun event(id:String,kind:String){enqueue("/messages/$id/events",JSONObject().put("kind",kind));dao.get(id)?.let{dao.save(it.copy(status=kind))}}
 suspend fun sync()=mutex.withLock {
  if(vault.role!="child"||vault.token.isEmpty())return@withLock
  val me=api.call("/me");vault.info=me.toString()
  if(me.optLong("session_expires",Long.MAX_VALUE)-System.currentTimeMillis()/1000<86400){val fresh=api.call("/auth/refresh",JSONObject());vault.token=fresh.getString("token")}
  val fid=vault.fid
  if(fid.isNotEmpty())api.call("/push/register",JSONObject().put("fid",fid).put("platform","android"))
  val heartbeat=JSONObject().put("version",BuildConfig.VERSION_NAME).put("notifications",NotificationManagerCompat.from(context).areNotificationsEnabled())
  if(vault.batteryConsent){val battery=(context.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager).getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY);if(battery in 0..100)heartbeat.put("battery",battery)}
  api.call("/devices/${me.getString("device_id")}/heartbeat",heartbeat)
  for(job in dao.pending()){
   try{val body=JSONObject(job.body)
    if(job.file!=null&&!body.has("attachment_id")){body.put("attachment_id",api.upload(File(job.file),job.family!!,job.id));dao.queue(job.copy(body=body.toString(),file=null));File(job.file).delete()}
    api.call(job.path,body);dao.done(job.id)
   }catch(e:ApiError){if(e.code==401||e.code==403)throw e;if(e.code==409&&job.path.endsWith("/events")){dao.done(job.id)}else{dao.queue(job.copy(attempts=job.attempts+1,error=e.message));continue}}
  }
  val items=org.json.JSONArray();var cursor:String?=null
  do{val page=api.call("/messages"+(cursor?.let{"?cursor="+java.net.URLEncoder.encode(it,"UTF-8")}?:""));val list=page.getJSONArray("items");for(i in 0 until list.length())items.put(list.getJSONObject(i));cursor=if(page.isNull("next_cursor"))null else page.getString("next_cursor")}while(cursor!=null)
  for(i in 0 until items.length()){
   val m=items.getJSONObject(i);val id=m.getString("id");val old=dao.get(id)
   val row=CachedMessage(id,m.toString(),m.getInt("priority"),m.getLong("created"),m.getLong("expires"),m.getString("status"),old?.notified?:false,old?.shown?:0,old?.nextShow?:0)
   dao.save(row) // Persist BEFORE ACK.
   if(m.getString("direction")=="to_child"&&m.isNull("delivered")&&QueuePolicy.live(row)){
    enqueue("/messages/$id/events",JSONObject().put("kind","delivered"))
   }
   if(!row.notified&&m.getString("direction")=="to_child"&&QueuePolicy.live(row)){
    dao.save(row.copy(notified=true));notifyOnce(context,id,"Новое сообщение от семьи")
   }
  }
 }
}
object QueuePolicy {
 fun live(m:CachedMessage,now:Long=System.currentTimeMillis()/1000)=m.expires>now&&m.status !in listOf("confirmed","replied","cancelled","expired")
 fun delaySeconds(priority:Int)=if(priority==2)1L else if(priority==1)30L else Long.MAX_VALUE/1000
 fun maxShows(priority:Int)=when(priority){2->3;1->2;else->1}
 fun next(rows:List<CachedMessage>,now:Long=System.currentTimeMillis()/1000)=rows.filter{live(it,now)&&it.shown<maxShows(it.priority)&&it.nextShow<=now&&JSONObject(it.json).optString("direction")=="to_child"}.sortedWith(compareByDescending<CachedMessage>{it.priority}.thenBy{it.created}).firstOrNull()
}
fun notifyOnce(context:Context,id:String,text:String){
 if(!NotificationManagerCompat.from(context).areNotificationsEnabled())return
 val intent=Intent(context,MainActivity::class.java).putExtra("message_id",id)
 val pending=PendingIntent.getActivity(context,id.hashCode(),intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
 val n=NotificationCompat.Builder(context,"family").setSmallIcon(android.R.drawable.ic_dialog_email).setContentTitle("Kuiz Family").setContentText(text).setContentIntent(pending).setAutoCancel(true).setOnlyAlertOnce(true).setVisibility(NotificationCompat.VISIBILITY_PRIVATE).build()
 try{NotificationManagerCompat.from(context).notify(id.hashCode(),n)}catch(_:SecurityException){}
}
class SyncWorker(ctx:Context,p:WorkerParameters):CoroutineWorker(ctx,p){override suspend fun doWork():Result=try{Repository(applicationContext).sync();Result.success()}catch(e:ApiError){if(e.code==401||e.code==403)Result.failure() else Result.retry()}catch(_:Exception){Result.retry()}
 companion object {
 fun enqueue(c:Context){WorkManager.getInstance(c).enqueueUniqueWork("family-sync",ExistingWorkPolicy.APPEND_OR_REPLACE,OneTimeWorkRequestBuilder<SyncWorker>().setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).setBackoffCriteria(BackoffPolicy.EXPONENTIAL,15,TimeUnit.SECONDS).build())}
 fun schedule(c:Context){WorkManager.getInstance(c).enqueueUniquePeriodicWork("family-periodic",ExistingPeriodicWorkPolicy.KEEP,PeriodicWorkRequestBuilder<SyncWorker>(15,TimeUnit.MINUTES).setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build())}
 }}
class PushService:FirebaseMessagingService(){
 override fun onRegistered(installationId:String){Vault(this).fid=installationId;SyncWorker.enqueue(this)}
 override fun onMessageReceived(m:RemoteMessage){
  val v=Vault(this)
  if(v.role=="parent"){
   val event=m.data["event_id"]?:return
   val prefs=getSharedPreferences("push-events",MODE_PRIVATE)
   if(!prefs.getBoolean(event,false)){prefs.edit().putBoolean(event,true).apply();notifyOnce(this,m.data["message_id"]?:event,"Новое событие в семье")}
  }else SyncWorker.enqueue(this)
 }
}

class ReminderWorker(ctx:Context,p:WorkerParameters):CoroutineWorker(ctx,p){
 override suspend fun doWork():Result{
  val id=inputData.getString("id")?:return Result.success();val repo=Repository(applicationContext)
  try{repo.sync()}catch(_:Exception){}
  val row=repo.dao.get(id)?:return Result.success()
  if(QueuePolicy.live(row)&&row.priority!=2)notifyOnce(applicationContext,id,"Сообщение семьи ждёт ответа")
  return Result.success()
 }
 companion object{fun afterDismiss(c:Context,m:CachedMessage){
  if(m.priority==2)return
  val prefs=c.getSharedPreferences("reminder-once",Context.MODE_PRIVATE)
  if(prefs.getBoolean(m.id,false))return
  prefs.edit().putBoolean(m.id,true).commit()
  // A soft message has one reminder; medium gets at most two total.
  val count=if(m.priority==1)2 else 1
  for(i in 1..count)WorkManager.getInstance(c).enqueueUniqueWork("reminder-${m.id}-$i",ExistingWorkPolicy.KEEP,OneTimeWorkRequestBuilder<ReminderWorker>().setInputData(workDataOf("id" to m.id)).setInitialDelay((i*15).toLong(),TimeUnit.SECONDS).build())
 }}
}

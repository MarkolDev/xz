package `fun`.markol.kuizfamily

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.room.*
import kotlinx.coroutines.flow.Flow
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import java.security.KeyStore

class Vault(context:Context) {
 private val prefs=context.getSharedPreferences("vault",Context.MODE_PRIVATE)
 private fun key():SecretKey {
  val store=KeyStore.getInstance("AndroidKeyStore").apply{load(null)}
  (store.getKey("kuiz-token",null) as? SecretKey)?.let{return it}
  return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore").apply{init(KeyGenParameterSpec.Builder("kuiz-token",KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())}.generateKey()
 }
 var token:String
 get(){val raw=prefs.getString("token",null)?:return "";return try{val b=Base64.decode(raw,Base64.NO_WRAP);Cipher.getInstance("AES/GCM/NoPadding").run{init(Cipher.DECRYPT_MODE,key(),GCMParameterSpec(128,b.copyOfRange(0,12)));String(doFinal(b.copyOfRange(12,b.size)))}}catch(_:Exception){""}}
 set(value){if(value.isEmpty()){prefs.edit().remove("token").apply();return};val c=Cipher.getInstance("AES/GCM/NoPadding");c.init(Cipher.ENCRYPT_MODE,key());prefs.edit().putString("token",Base64.encodeToString(c.iv+c.doFinal(value.toByteArray()),Base64.NO_WRAP)).apply()}
 var role:String
 get()=prefs.getString("role","")?:""
 set(v){prefs.edit().putString("role",v).apply()}
 var fid:String
 get()=prefs.getString("fid","")?:""
 set(v){prefs.edit().putString("fid",v).apply()}
 var info:String
 get()=prefs.getString("info","{}")?:"{}"
 set(v){prefs.edit().putString("info",v).apply()}
 var batteryConsent:Boolean
 get()=prefs.getBoolean("batteryConsent",false)
 set(v){prefs.edit().putBoolean("batteryConsent",v).apply()}
 var theme:String
 get()=prefs.getString("theme","auto")?:"auto"
 set(v){prefs.edit().putString("theme",v).apply()}
}
@Entity(tableName="messages") data class CachedMessage(@PrimaryKey val id:String,val json:String,val priority:Int,val created:Long,val expires:Long,val status:String,val notified:Boolean=false,val shown:Int=0,val nextShow:Long=0)
@Entity(tableName="outbox") data class Pending(@PrimaryKey val id:String,val path:String,val body:String,val file:String?=null,val family:String?=null,val attempts:Int=0,val error:String?=null)
@Dao interface CacheDao {
 @Query("SELECT * FROM messages ORDER BY priority DESC, created ASC") fun observe():Flow<List<CachedMessage>>
 @Query("SELECT * FROM messages ORDER BY priority DESC, created ASC") suspend fun list():List<CachedMessage>
 @Query("SELECT * FROM messages WHERE id=:id") suspend fun get(id:String):CachedMessage?
 @Upsert suspend fun save(message:CachedMessage)
 @Upsert suspend fun queue(pending:Pending)
 @Query("SELECT * FROM outbox") suspend fun pending():List<Pending>
 @Query("SELECT COUNT(*) FROM outbox") fun count():Flow<Int>
 @Query("DELETE FROM outbox WHERE id=:id") suspend fun done(id:String)
 @Query("DELETE FROM messages") suspend fun clearMessages()
 @Query("DELETE FROM outbox") suspend fun clearOutbox()
}
@Database(entities=[CachedMessage::class,Pending::class],version=1,exportSchema=false)
abstract class Cache:RoomDatabase(){abstract fun dao():CacheDao
 companion object {@Volatile private var instance:Cache?=null
 fun get(c:Context):Cache=instance?:synchronized(this){instance?:Room.databaseBuilder(c.applicationContext,Cache::class.java,"family.db").build().also{instance=it}}
 }}

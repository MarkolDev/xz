# Проверка исходного ТЗ

Статус относится к коду версии 0.1.0. «Реализовано» не означает проверку на реальном
планшете или настройку вашего сервера. Реальные результаты — в TEST_RESULTS.md.

| Пункт | Реализация | Ограничение / остаток |
|---|---|---|
| Один APK, две роли | Compose ребёнок, ограниченная WebView родителя, проверка прав сервером | Нет испытаний на физическом устройстве |
| Invite-only | CLI bootstrap, хешированные expiring приглашения, SMTP, reset, Argon2id | Нужны SMTP и проверка реальной почты; CLI invite доставлять только на указанный email |
| Pairing | QR на планшете, ручной ввод, preview названия, атомарное подтверждение в PostgreSQL, отдельный claim secret | QR web-сканер через BarcodeDetector с ручным fallback; испытания камеры и одновременных PostgreSQL транзакций требуют отдельной проверки |
| Material 3 | Настоящие @material/web + Compose Material3, динамическая тема ребёнка | Нет визуального QA и TalkBack/клавиатурного e2e на устройствах |
| Текст и медиа | Реальный API, ffprobe, UUID, приватный доступ, запись web/native, ответы | Запись native через системную камеру; кадр не обрезается в круг при сохранении, круг — представление; медиа требует ffprobe |
| Статусы/offline | Durable DB events/outbox, idempotency, Room, WorkManager, IndexedDB, TTL | Web не устанавливается как полноценная offline PWA; Android DB не дополнительно зашифрована SQLCipher |
| Три важности | Ограниченная foreground очередь, безопасный выход, нет фонового Activity launch | WorkManager не гарантирует точный интервал; нет обещания перекрыть YouTube |
| PIN | 4 нажатия и явная кнопка, Argon2id, 5 попыток/15 минут, 5 минут доступа | PIN проверяется только онлайн, выход доступен всегда; событие PIN фиксируется в аудите и отправляется взрослым через очередь push |
| Push FID | Современные API Android/web/Admin, отдельные native/web регистрации, privacy payload, retry | Нужен Firebase config; реальные push не испытаны; normal-priority доставка может задерживаться |
| Dual-route | Детский bearer transport переключается только при network/5xx | Полный failover веба/родительского WebView отсутствует; cookie остаётся на canonical origin |
| Статус устройства | heartbeat, version, permissions; API принимает battery opt-in | Передача заряда включается только отдельным Switch; GPS и чужие приложения не собираются |
| Общение | Ребёнок пишет первым, история, приоритеты, шаблоны, запланированная отправка | Нет группового разговорного thread UX; есть выбор одного/нескольких устройств |
| Админка | Health DB/FCM/queue, invites, аудит, доверенные сессии, test-push API | MFA не реализована; не все API выведены в UI (отзыв релиза, редактирование staged rollout); изолированные сценарии сбоев покрыты тестами, отдельного UI симулятора нет |
| APK-релизы | Scanner, package/signature/version/hash, review publish, notes, staged API, revoke, system installer | Нужны Android build tools + ClamAV + trusted cert на сервере; Play In-App Updates отсутствует |
| Установка | Конфиги env/SMTP/FCM, Windows scripts, VPS guide, nginx/systemd, signed DB backup | Нет фактической установки на вашем VPS; настройки DNS/ключи остаются владельцу |
| Исходники/проверка | Полный код, миграции, backend tests, Kotlin policy tests, CI, build logs | PostgreSQL CI и физический Android e2e не запущены в этой среде |

## До повседневного использования

1. Настроить VPS, PostgreSQL, HTTPS на оба домена, SMTP и Firebase, постоянную подпись APK.
2. Выполнить тест реальной привязки и перепривязки, отзыва, media, push и 2-часового offline.
3. Проверить Android 14–17: закрытое приложение, отключённые уведомления/канал,
   Doze, перезагрузка, поворот, font scaling, TalkBack, безопасный выход.
4. Запустить PostgreSQL CI, нагрузочные/конкурентные проверки и restore backup.
5. Доработать перечисленные продуктовые пробелы: web failover, админские UI-инструменты,
   MFA, полный offline-web bootstrap.

Не выдавать эту версию за полностью прошедшую исходную приёмку. Основная связка
реализована в настоящем коде; непроверенные внешние интеграции не имитируются.

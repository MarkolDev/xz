# Результаты проверки — 24 октября 2026

## Успешно выполнено в этой среде

| Проверка | Результат |
|---|---|
| `python -m pytest -q` | **26 passed**, 11.31 секунды; SQLite с включёнными foreign keys |
| Миграции на пустой БД | Все 3 ревизии успешно применены |
| `npm run build` | Успешная production-сборка web и Firebase service worker |
| HTTP built frontend | index.html и подключённый JS возвращают 200; неавторизованный `/me` возвращает 401 |
| `gradle clean wrapper testDebugUnitTest assembleDebug` | **BUILD SUCCESSFUL**, 57 секунд |
| Kotlin unit tests | **3 tests, 0 failures, 0 errors** |
| `apksigner verify --verbose --print-certs` | APK успешно проверен, debug-подпись |

Логи приложены в `docs/build-logs/`. APK — `dist/KuizFamily-0.1.0-debug.apk`.
SHA-256 — `dist/SHA256SUMS.txt`. APK около 14.5 МБ, package `fun.markol.kuizfamily`,
versionName 0.1.0, versionCode 1, minSdk 26, target/compileSdk 37.

Сборка: JDK 17.0.20, Gradle 9.3.1, Android Gradle Plugin 9.1.1, Kotlin 2.3.0,
Compose BoM 2026.09.00, Android SDK Platform 37.0 и Build Tools 36.0.0.
Сохранён официальный Gradle wrapper с SHA-256 дистрибутива.

## Что проверяют серверные тесты

Приглашения и replay; вход/CSRF/Origin; привязка и чужой claim secret; TTL кодов;
изоляция семей; запрет родителю подделывать device ACK; idempotency сообщений,
ответов и медиа; отмена/просрочка; отзыв сессии/устройства; PIN brute force;
настоящий ffmpeg/ffprobe audio upload; закрытый доступ и удаление медиа;
устойчивая очередь FCM и восстановление lease после сбоя; запуск расписания;
отмена до push; неизменность delivery при принятии FCM; доверенные админ-сессии;
проверка APK с отказом при недоступных валидаторах; cursor pagination для сообщений
с одинаковой секундой создания; удаление старого контента по retention;
ротация детской сессии; ребёнок пишет первым.

Kotlin-тесты проверяют TTL, прекращение повторов после подтверждения/отмены,
пределы количества показов и интервал для «Важно».

## Что не было проверено

- Реальная доставка Firebase, SMTP и домены/VPS пользователя: ключи не предоставлены.
- PostgreSQL в исполненной тестовой сессии: предусмотрен отдельный CI job, но здесь
  тесты выполнялись на SQLite. CI в GitHub не запускался.
- Физический Android: UI, камера/микрофон, push/Doze/перезагрузка, обновление APK,
  TalkBack, поворот планшета, Android 14–17. Успех компиляции не заменяет эти проверки.
- Визуальный browser QA: облачный браузер не смог подключиться к локальному
  тестовому серверу (ERR_CONNECTION_REFUSED); изображений «проверенного UI» нет.
- Публикация правильно подписанного APK через реальный ClamAV/aapt/apksigner сервер:
  протестирована защита от непроверенного файла, не внешняя инфраструктура релизов.

Собранный APK **не содержит google-services.json**. После настройки Firebase его
нужно пересобрать с конфигурацией проекта. Сервер не развёрнут на ваших доменах.
При первом запуске без сервера приложение не сможет завершить привязку.

AGP 9.1 сохраняет совместимый режим Kotlin/kapt (`android.builtInKotlin=false`,
`android.newDsl=false`); сборка выдаёт предупреждения об удалении этого режима в
AGP 10. Для будущего обновления перейти на встроенный Kotlin/KSP. Нативные debug
библиотеки упакованы без stripping; это не ошибка сборки.

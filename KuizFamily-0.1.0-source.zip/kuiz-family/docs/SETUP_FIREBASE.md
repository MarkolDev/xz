# Firebase: настройка владельцем

В проекте нет сервисного ключа и Firebase project ID. Без них APK работает с API,
локальной очередью и foreground-синхронизацией, но **push не подключён**.

1. Создай Firebase project в https://console.firebase.google.com/ . Analytics не нужен.
2. Добавь Android app с package `fun.markol.kuizfamily`. Скачай `google-services.json`
   в `android/app/`. Это конфигурация клиента, не сервисный приватный ключ.
3. Добавь Web app. Public config и `vapidKey` помести одним JSON в
   `FIREBASE_WEB_CONFIG` серверного окружения. Не вставляй туда Admin credentials.
4. Project settings → Cloud Messaging → Web Push certificates: создай VAPID key.
   Включи Firebase Cloud Messaging API (HTTP v1) в Google Cloud.
5. Project settings → Service accounts → Firebase Admin SDK: ключ сохрани **вне
   репозитория**, например `/etc/kuiz-family/firebase-service-account.json`.
   Файл доступен только service user. Задай `GOOGLE_APPLICATION_CREDENTIALS`.
   Предпочти workload identity, если хостинг её поддерживает.
6. Пересобери APK. Перезапусти API и worker. После входа нажми
   «Разрешить уведомления» / «Включить уведомления».
7. В Android используются `onRegistered(installationId)` и `register()`, metadata
   `firebase_messaging_installation_id_enabled=true`; web использует `register`
   и `onRegistered`; Python — `messaging.Message(fid=...)`. Legacy token API нет.
8. Web service worker лежит в корне: `/firebase-messaging-sw.js`. Он отображает
   общую фразу, дедуплицирует event_id, открывает только свой origin.
9. В native WebView браузерная push-регистрация отключена; FID регистрирует оболочка
   после появления авторизованной cookie. Это предотвращает web/native дубль.
10. Проверяй на физическом устройстве с Google Play Services: foreground/background,
    запрещённые уведомления, выключенный канал, Doze, перезагрузка, отсутствие сети.
    При отсутствии Play Services: уведомления FCM недоступны, открытое приложение
    синхронизируется; WorkManager не гарантирует мгновенную доставку.

Все отправки — normal-priority data-only sync. Успех Admin SDK отмечается только
как отправка FCM. `delivered` выставляет планшет после сохранения в Room.
При задержках normal priority не повышай тихие сигналы до HIGH без видимого
уведомления и проверки требований Firebase.

## Проверенные источники, 24.10.2026
- https://firebase.google.com/docs/cloud-messaging/android/get-started
- https://firebase.google.com/docs/cloud-messaging/web/get-started
- https://firebase.google.com/docs/reference/admin/python/firebase_admin.messaging
- https://firebase.google.com/docs/cloud-messaging/android-message-priority
- https://firebase.google.com/support/release-notes/android
- https://firebase.google.com/support/release-notes/js

Зависимости закреплены: firebase-admin 7.7.0, JS 13.1.0, Android BoM 35.1.0.
Проверка настоящей доставки требует вашего Firebase-проекта; в автоматических
тестах используется явно подставленный fake sender, не имитация боевой отправки.

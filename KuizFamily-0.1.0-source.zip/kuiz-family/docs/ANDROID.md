# Android

Открой `android/` в Android Studio, установи SDK Platform 37, Build Tools 36.0.0,
JDK 17. Gradle wrapper включён. Сборка:

```powershell
cd android
.\gradlew.bat testDebugUnitTest assembleDebug
```

Linux: `./gradlew testDebugUnitTest assembleDebug`.
APK: `app/build/outputs/apk/debug/app-debug.apk`. Package: `fun.markol.kuizfamily`.
Исходники разделены: Storage (Room/Keystore), Network (HTTPS transport), Sync
(WorkManager/FCM/очередь), MainActivity (Compose и изолированный WebView).

Для push добавь свой `app/google-services.json` и пересобери. Без него сборка
допустима: FirebaseApp не инициализирован, основной API продолжает работать.
Заданные адреса: kfml.markol.fun и prkfml.markol.fun. Для другого сервера меняй
allowlist в Network.kt и ParentScreen, PUBLIC_ORIGIN и Nginx одновременно.
Нет пользовательского переключения на произвольные небезопасные URL.

## Поведение ребёнка

- Material 3, Dynamic Color с Android 12, fallback для Android 8–11.
- Никаких overlay permissions, Accessibility service, device admin, fullscreen
  intent, exact alarm или принудительной остановки чужой музыки.
- Сообщение повторяется только в открытом экране. «Важно»: максимум 3 показа,
  примерно через секунду; повторных уведомлений после закрытия нет.
- «Средне»: максимум 2 показа внутри приложения и 2 ограниченных напоминания.
  «Мягко»: один показ и не более одного напоминания. WorkManager не обещает точные
  15/30 секунд; ОС может отложить фоновые напоминания.
- Очередь UUID: важность, затем время. Открытый ответ не прерывается.
- Отправка сохраняется в Room до сети. Доставка ACK только после локальной записи.
- Четыре нажатия открывают PIN, но не дают доступ. Проверка серверная; офлайн PIN
  не проверяется. Доступный выход остаётся всегда, экстренные функции не блокируются.
- Android Keystore шифрует bearer token, backup отключён. Room/private media хранятся
  в app-private storage под системной защитой; отдельное шифрование всей DB не включено.

## Подпись release

Создай постоянный keystore вне репозитория через Android Studio → Generate Signed
Bundle / APK. Сохрани резервную копию ключа, пароль не записывай в Gradle. Для всех
обновлений нужен тот же ключ. Debug APK из разных сборочных окружений может иметь
другую подпись; его нельзя бесшовно обновить поверх другой debug-подписи.
Для Google Play нужен отдельный канал/официальный In-App Updates; эта версия
предназначена для частной установки APK и не заявляет готовность к Google Play.

Физические испытания Android 14–17, TalkBack, поворота планшета, запрещённых
уведомлений, записи камеры и системного установщика обязательны перед использованием.

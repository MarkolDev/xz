# Сторонние компоненты

Исходный проект использует библиотеки под их собственными лицензиями:
Material Web, AndroidX/Compose/Room/WorkManager, Firebase SDK, OkHttp, ZXing,
Flask, SQLAlchemy, Alembic, Argon2 и Gradle. Лицензии и notices не меняются.

Material Web / AndroidX / Firebase / OkHttp / ZXing / Gradle: Apache License 2.0.
Flask: BSD-3-Clause. SQLAlchemy / Alembic: MIT. Vite: MIT. Полный список
web-зависимостей с точными версиями — `web/package-lock.json`; Python —
`backend/requirements.txt`; Android — Gradle build files и resolved dependencies.

Системный шрифт используется без встраивания. Брендовые изображения не включены;
фотография кота из вложения не используется в продукте, потому что ТЗ требует
самостоятельный Material You-дизайн.

# Установка на отдельный порт существующего VPS

Ничего не меняй в конфигурациях Markuiz / Night Worlds. У Kuiz Family отдельные
пользователь ОС, каталог, PostgreSQL DB, service и Nginx vhost. Порт в примере 8078:
сначала проверь `ss -ltnp`, что он свободен.

## Ubuntu 22.04 / 24.04

Нужны Python 3.11+ (рекомендуется 3.13), venv, PostgreSQL 16, Nginx, ffmpeg,
certbot, Node 22 только для пересборки web. На Ubuntu 22.04 системный Python 3.10
**не заменяй**: установи отдельный поддерживаемый Python и используй его для venv.

1. Создай системного пользователя `kuiz-family`, каталог `/opt/kuiz-family`,
   каталог `/var/lib/kuiz-family/media`, владелец service user.
2. Распакуй исходники в `/opt/kuiz-family`. Создай `.venv`, установи
   `backend/requirements.txt`. Готовый `web/dist` входит в архив; пересборка:
   `cd web && npm ci && npm run build`.
3. Создай PostgreSQL роль `kuiz_family` и базу с этим владельцем. Пароль задавай
   интерактивно (`\password kuiz_family`), не копируй реальные пароли в команды чата.
4. Скопируй `.env.example` в `/etc/kuiz-family.env`. Права 640, группа service user.
   Заполни DATABASE_URL, MEDIA_ROOT, SMTP и Firebase. Не включай COOKIE_SECURE=false
   в production. `.env` для Flask CLI можно использовать в `backend/`, но systemd
   читает только EnvironmentFile. Экспортируй то же окружение для CLI-команд.
5. В `backend/`: `../.venv/bin/flask --app kuiz db upgrade`, затем
   `../.venv/bin/flask --app kuiz create-admin`. Команда спрашивает email, имя и пароль.
6. Установи два unit-файла из `deploy/`, проверь пути. Выполни
   `systemctl daemon-reload`, `systemctl enable --now kuiz-family kuiz-family-worker`.
7. DNS: A `kfml.markol.fun` → VPS, **DNS Only**; A `prkfml.markol.fun` → тот же VPS,
   **Proxied**. В Cloudflare SSL/TLS — Full (strict). Это два маршрута, не два сервера.
8. Сначала включи HTTP vhost с ACME location, получи сертификат на ОБА имени:
   `certbot certonly --webroot -w /var/www/letsencrypt -d kfml.markol.fun -d prkfml.markol.fun`.
   Потом включи HTTPS секцию из `deploy/nginx.conf`. Проверь `nginx -t`, затем reload.
9. Войди на https://kfml.markol.fun , создай семью. В настройках задай PIN.
   Подключи планшет кодом. Отправь текст и посмотри отдельные статусы доставки.

Nginx не отдаёт media напрямую: чтение идёт через авторизованный API. Не публикуй
`/var/lib/kuiz-family` как static root. Worker должен иметь доступ к той же DB/media.
Ограничь firewall: извне 80/443; PostgreSQL и gunicorn только loopback.

## Windows 10: быстрый локальный запуск

Установи Python 3.13. Распакуй архив и запусти `scripts/start-dev.bat`.
Он создаёт venv, ставит зависимости, применяет миграции и открывает API на
http://127.0.0.1:8078 (открой адрес браузером). Встроенная SQLite — только development.
В отдельном терминале из `backend` выполни:

```powershell
..\.venv\Scripts\python.exe -m flask --app kuiz create-admin
```

Для PostgreSQL development можно запустить `docker compose up -d` после установки
POSTGRES_PASSWORD, затем задать DATABASE_URL. Для записи медиа нужен `ffprobe`
в PATH (пакет ffmpeg). Worker запускается отдельно: `python -m kuiz.worker`.

## Резервные копии

Задай стандартные PGHOST/PGPORT/PGUSER/PGDATABASE/PGPASSWORD без вывода в лог.
Создай случайный 32-байтный ключ вне репозитория. Команда:
`python scripts/backup.py backup backup.dump --key-file /secure/backup.key`.
Скрипт создаёт dump и HMAC-подпись. Храни ключ отдельно от копий, копируй также
каталог media безопасным инструментом. HMAC обеспечивает целостность, не шифрование.
Восстановление сначала в пустую тестовую DB; скрипт проверяет подпись, требует
`--confirm-restore`. Резервные копии содержат личные сообщения: ограничь доступ.

## APK-релизы

На сервере нужны `aapt`, `apksigner`, `clamscan` с актуальными сигнатурами.
Укажи ожидаемый SHA-256 сертификата для каждого канала в APK_CERT_DEBUG/RELEASE.
Без этой настройки загрузка намеренно отклоняется. Не доверяй сертификату из
самого первого загруженного APK. Админ повторно вводит пароль и доверяет своей
сессии на сутки, затем загружает APK, проверяет метаданные и публикует описание.
Установка на Android только через системный установщик с подтверждением.

## Маршруты и ограничения

Нативный детский API пробует второй host только после IOException/timeout/5xx;
401/403/валидация не переключают маршрут. Bearer не передаётся вне двух заданных
HTTPS-хостов. На вебе/родительском WebView cookie привязана к canonical origin;
полный автоматический web-failover между доменами пока не реализован. При сбое
canonical origin открытая панель сохраняет отправку в IndexedDB; закрытая панель
без сети не загружается. Не копируй HttpOnly cookie между двумя доменами вручную.
